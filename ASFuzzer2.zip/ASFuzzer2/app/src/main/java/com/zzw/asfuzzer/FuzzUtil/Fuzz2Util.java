package com.zzw.asfuzzer.FuzzUtil;

import android.content.Intent;
import android.net.Uri;
import android.os.IBinder;
import android.util.Log;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

public class Fuzz2Util {
    List list1 = new ArrayList();
    List list = new ArrayList();
    HashMap<String,List> objmap= new HashMap<>();
    public static Random rand=new Random();
    public byte[] byte_para={0,1,101,-56,89,-89,-110,-1,Byte.MAX_VALUE,Byte.MIN_VALUE};
    public int[] int_para={0,1,-1,Integer.MAX_VALUE,1234567,Integer.MIN_VALUE,rand.nextInt(),-1234567};
    private static ArrayList<Integer> tmpArr2 = new ArrayList<>();
    static List linelist=new ArrayList();
    static List bindlist2=new ArrayList();
    static int temp=0;
    static int count=0;
    public static int times=0;

    static long longtemp=0;
    static int longcount=0;
    static int longtimes=0;

    static float floattemp=0;
    static int floatcount=0;
    static int floattimes=0;

    static long longarraytemp=0;
    static int longarraycount=0;
    //static long temp1 = 0;
    static int longarraytimes=0;

    static double doubletemp=0;
    static int doublecount=0;
    static int doubletimes=0;



    /**
 * 处理复杂参数
 */
    public  Object[] MultiPara(String style){
        Object[] object=null;
        if(style.contains("[L")||style.contains("\\;")){  //如果复杂数据为对象数组，则进行数据拆分
            style=style.substring(2, style.length()-1);
            Log.e("参数为数组",style+"");
        }
        try {
            object= Getinstance(style);         //获取实例
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        }
        return object;   //最后返回的是一个对象数组
    }

    public   Object[] Getinstance(String Para) throws ClassNotFoundException, IllegalAccessException, InvocationTargetException, InstantiationException {
        Object[] object=null;
        Object obj=null;
        Class<?> cla = Class.forName(Para);
        Constructor<?>[] construct = cla.getConstructors();  //获取构造函数
        int len = construct.length;  //构造参数个数
        if (len == 0) {            //没有反射,直接参数为空。
            Log.e("re", "参数为空");
            return object;
        }
        else{                    //有构造函数
            object=new Object[len];
            Log.e("re", "有"+len+"个构造参数！");
            for(int j=0;j<len;j++){
                boolean flag=true;
                construct[j].setAccessible(true);
                Class<?>[] parame = construct[j].getParameterTypes();
                if(parame.length==0){               //空构造函数
                    Log.e("构造",construct[j].getName());
                    Object obj0=construct[j].newInstance();     //直接构造一个实例
                    object[j]=obj0;
                }
                else{
                    if(parame.length>5){   //如果个数超过5个就不构造了
                        break;
                    }
                    for (Class para : parame) {
                        list1.add(para.getName());
                    }
                    for(int i=0;i<list1.size();i++){//向构造参数中添加实际数字进行构造
                        String style = (String) Getlistdata.GetParaStyleRelation().get(list1.get(i));
                        if(style==null){ //构造参数中有复杂参数，直接返回空
                            flag=false;
                            break;
                        }
                        objmap = evaluatePara(style,i);
                    }
                    if(flag==false){
                        break;
                    }
                    Object[] ob=new Object[objmap.size()];
                    for(int k=0;k<objmap.size();k++){
                        ob[k]=objmap.get("para"+k).get(k);
                    }
                    obj=construct[j].newInstance(ob);
                    object[j]=obj;
                }
                list.clear();
                list1.clear();
                objmap.clear();
            }


            Log.e("类型",object.length+" ");
        }
        return object;
    }
    /**
     *
     * 处理对象数组中的参数，只保留常规数据类型。复杂类型则不考虑。
     * @param style
     * @param i
     * @return
     */

    public HashMap evaluatePara(String style, int i) {
        int caseStyle= Integer.parseInt(style.split(" ")[1]);

        switch (caseStyle) {
            case 1:
                list.add(DataUtil.getRandomint(1,1000));
                objmap.put("para"+i,list);
                return objmap;
            //Log.e("type", 1 + "类型");
            case 2:
                //int[] 整型数组
                int[] intarry=getIntarray(rand.nextInt(64));
                list.add(intarry);
                objmap.put("para"+i,list);
                return objmap;
            case 3:
                //byte 字节型
                int x=DataUtil.getRandomint(1,10);   //获取随机值，来定位byte数组中的数据。
                list.add(byte_para[x]);
                objmap.put("para"+i,list);
                return objmap;
            case 4:
                //byte[] 字节数组
                byte[] bytearry=DataUtil.getbyteArry(rand.nextInt(64));
                list.add(bytearry);
                objmap.put("para"+i,list);
                return objmap;
            case 5:
                long long1=getLong();
                list.add(long1);
                objmap.put("para"+i,list);
                return objmap;
            case 6:
                long []longarry=getLongarray(rand.nextInt(64));
                list.add(longarry);
                objmap.put("para"+i,list);
                return objmap;
            case 7:
                float float1=getfloat();
                list.add(float1);
                objmap.put("para"+i,list);
                return objmap;
            case 8:
                float[] floatarry=getfloatarray(rand.nextInt(64));
                list.add(floatarry);
                objmap.put("para"+i,list);
                return objmap;
            case 9:
                double double1=getdouble();
                list.add(double1);
                objmap.put("para"+i,list);
                return objmap;
            case 10:
                double[] doublearry=getDoubleArry(rand.nextInt(64));
                list.add(doublearry);
                objmap.put("para"+i,list);
                return objmap;
            case 11:
                list.add(DataUtil.getBoolean());
                objmap.put("para"+i,list);
                return objmap;
            case 12:
                boolean [] boolarry=DataUtil.getbooleanArray(rand.nextInt(16)+1);
                list.add(boolarry);
                objmap.put("para"+i,list);
                return objmap;
            case 13:
                //String 字符串型
                list.add(DataUtil.getRandomString(DataUtil.getRandomint(1,31)));
                objmap.put("para"+i,list);
                return objmap;
            case 14:
                //String[]  字符串数组
                String [] str=DataUtil.getStrArray(rand.nextInt(32)+1);
                list.add(str);
                objmap.put("para"+i,list);
                return objmap;
            case 15:
                //Ibinder类型
                IBinder binder1;
                try {
                    bindlist2=DataUtil.getbinder();
                    binder1= (IBinder) bindlist2.get(rand.nextInt(100)+1);
                    list.add(binder1);

                    objmap.put("para"+i,list);
                    return objmap;
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } catch (NoSuchMethodException e) {
                    e.printStackTrace();
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                } catch (InvocationTargetException e) {
                    e.printStackTrace();
                }



            case 17:
                //intent 双精度型数组
                Intent intent1=DataUtil.GetIntent(rand.nextInt(48)+1);
                list.add(intent1);
                objmap.put("para"+i,list);
                return objmap;

            case 18:
                //intent[]数组
                Intent[] intentarry=DataUtil.getintentarry(rand.nextInt(48)+1);
                list.add(intentarry);
                objmap.put("para"+i,list);
                return objmap;
            case 19:
                List objlist=DataUtil.getList(rand.nextInt(30)+1);
                list.add(objlist);
                objmap.put("para"+i,list);
                return objmap;

            case 20:
                //URI类型
                Uri uri1=DataUtil.GetUri();
                list.add(uri1);
                objmap.put("para"+i,list);
                return objmap;
            case 23:

                list.add(DataUtil.getComPonentname(DataUtil.getRandomint(1,15)));
                objmap.put("para"+i,list);
                return objmap;
            default:
                list.add(null);
                objmap.put("para"+i,list);
                return objmap;
        }

    }

    public static float getfloat() {

        Random rand=new Random();
        floatcount+=1;
        String line;

        float floatvalue=floattemp;
        //System.out.println("第"+count+"次调用初始值为： "+value);
        float floatnext_value=0;
        String num="";
        float[] float_para={0,1,-1,Float.MAX_VALUE,Float.MIN_VALUE,Float.MIN_NORMAL,Float.MAX_EXPONENT,Float.MIN_EXPONENT,rand.nextFloat(),765768f};
        if(floatcount==1000){
            floatcount=1;
            floattimes=0;
        }
        if(floatcount%100==0) {
            System.out.println("count值###########"+floatcount);
            floatvalue=float_para[(floatcount/100)];
            System.out.println("换新值了"+floatcount+"  "+floatvalue);
        }
        if(floatcount-1<linelist.size()) {               //获取序列
            line=linelist.get((int) (floatcount-1)).toString();
        }
        else {
            line=linelist.get(floatcount%linelist.size()).toString();

        }
        String[] cx=line.substring(1, line.length()-1).split(",");
        for(int l=0;l<cx.length;l++) {
            num=cx[l].trim();
            switch(num) {
                case "1":
                    floatnext_value=floatvalue*floatvalue;

                    break;
                case "2":
                    floatnext_value=floatvalue*2f;

                    break;
                case "3":
                    floatnext_value=floatvalue*-1; //取反

                    break;
                case "4":
                    floatnext_value=(floatvalue+256)/2;
                    break;
                case "5":
                    floatnext_value=(int) Math.sqrt(floatvalue);
                    break;
                default:
                    System.out.println("没有执行到  :"+num);
            }
            floatvalue=floatnext_value;
        }
        floattemp=floatnext_value;
        if(floatnext_value==0) {
            floattimes+=1;
            if(floattimes>=2) {
                floatnext_value+=floattimes;
            }
        }
        return floatnext_value;
    }
    public static int[] getIntarray(int len) {
        int[] intarray=new int[len];
        Random rand=new Random();
        count+=1;
        String line;
        int value=temp;
        int next_value = 0;
        String num="";
        int[] int_para={0,1,-1,Integer.MAX_VALUE,1234567,45678,Integer.MIN_VALUE,rand.nextInt(),-1234567,-1237,99999999,567};
        if(count<11) {
            value=int_para[count];
        }
        else {
            value=int_para[count%11];
        }
        if(count%100==0) {
            count=1;
        }
        if(count-1<linelist.size()) {               //获取序列
            line=linelist.get(count-1).toString();
        }
        else {
            line=linelist.get(count%linelist.size()).toString();
        }
        for(int w=0;w<len;w++) {
            String[] cx=line.substring(1, line.length()-1).split(",");
            for(int l=0;l<cx.length;l++) {
                num=cx[l].trim();
                switch(num) {
                    case "1":
                        next_value=value*value;
                        break;
                    case "2":
                        next_value=value*2;
                        break;
                    case "3":
                        next_value=~value; //取反
                        break;
                    case "4":
                        next_value=(value+256)/2;
                        break;
                    case "5":
                        next_value=(int) Math.sqrt(value);
                        break;
                    default:
                        System.out.println("没有执行到  :"+num);
                }
                value=next_value;
            }
            if(next_value==0) {
                times+=1;
                if(times>=2) {
                    next_value+=times;
                }
            }
            intarray[w]=next_value;
        }
        return intarray;
    }
    public static long[] getLongarray(int len){
        long[] backlong=new long [len];
        for(int i=0;i<len;i++){
            backlong[i]=getlongnum();
        }
        return backlong;
    }
    public static long getlongnum() {

        Random rand=new Random();
        longarraycount+=1;
        String line;

        long longvalue=longarraytemp;
        //System.out.println("第"+count+"次调用初始值为： "+value);
        long longnext_value=0;
        String num="";
        long[] long_para={0,1,-1,Long.MAX_VALUE,rand.nextLong(),Long.MIN_VALUE};

        if(longarraycount==1000){
            longarraycount=1;
            longarraytimes=0;
        }
        if(longarraycount%100==0) {
            //System.out.println("count值###########"+longarraycount);
            longvalue=long_para[(longarraycount%6)];
            //System.out.println("换新值了"+longarraycount+"  "+longvalue);
        }
        if(longarraycount-1<linelist.size()) {               //获取序列
            line=linelist.get((int) (longarraycount-1)).toString();
        }
        else {
            line=linelist.get(longarraycount%linelist.size()).toString();
        }
        String[] cx=line.substring(1, line.length()-1).split(",");
        for(int l=0;l<cx.length;l++) {
            num=cx[l].trim();
            switch(num) {
                case "1":
                    longnext_value=longvalue*longvalue;
                    break;
                case "2":
                    longnext_value= (longvalue*2l);
                    break;
                case "3":
                    longnext_value=~longvalue; //取反
                    break;
                case "4":
                    longnext_value=(longvalue+123456)/2;
                    break;
                case "5":
                    longnext_value=(int) Math.sqrt(longvalue);
                    break;
                default:
                    System.out.println("没有执行到  :"+num);
            }
            longvalue=longnext_value;

        }
        longarraytemp=longnext_value;
        if(longnext_value==0) {
            longarraytimes+=1;
            if(longarraytimes>=2) {
                longnext_value+=longarraytimes;
            }
        }
        return longnext_value;
    }

    public static long getLong() {

        Random rand=new Random();
        longcount+=1;
        String line;

        long longvalue=longtemp;
        //System.out.println("第"+count+"次调用初始值为： "+value);
        long longnext_value=0;
        String num="";
        long[] long_para={0,1,-1,6565596567576575478L,Long.MAX_VALUE,57657,Long.MIN_VALUE,-8999999999999999999L,999999999,rand.nextLong(),5677};
        if(longcount==1000){
            longcount=1;
            longtimes=0;
        }
        if(longcount%100==0) {
            System.out.println("count值###########"+longcount);
            longvalue=long_para[(longcount/100)];
            System.out.println("换新值了"+longcount+"  "+longvalue);
        }
        if(longcount-1<linelist.size()) {               //获取序列
            line=linelist.get((int) (longcount-1)).toString();
        }
        else {
            line=linelist.get(longcount%linelist.size()).toString();

        }
        String[] cx=line.substring(1, line.length()-1).split(",");
        for(int l=0;l<cx.length;l++) {
            num=cx[l].trim();
            switch(num) {
                case "1":
                    longnext_value=longvalue*longvalue;

                    break;
                case "2":
                    longnext_value=longvalue*2;

                    break;
                case "3":
                    longnext_value=~longvalue; //取反

                    break;
                case "4":
                    longnext_value=(longvalue+123456789)/2;
                    break;
                case "5":
                    longnext_value=(int) Math.sqrt(longvalue);
                    break;
                default:
                    System.out.println("没有执行到  :"+num);
            }
            longvalue=longnext_value;

        }
        longtemp=longnext_value;
        // System.out.println("结果:"+next_value);
        if(longnext_value==0) {
            longtimes+=1;
            if(longtimes>=2) {
                longnext_value+=longtimes;
            }
        }
        return longnext_value;
    }

    public static float[] getfloatarray(int i){
        return getfloatarray1((i+1)%64);
    }
    public static float[] getfloatarray1(int len) {
        float min = -100f;
        float max = 100f;
        Random rand=new Random();
        float[] floatarray=new float[len];
        for(int i=0;i<len;i++) {
            floatarray[i]= min+ rand.nextFloat()*(max-min);
        }
        return floatarray;
    }
    public static double[] getDoubleArry(int len){
        double[] backdouble=new double[len];
        for(int i=0;i<len;i++){
            backdouble[i]=getdouble();
        }
        return backdouble;
    }
    public static double getdouble() {
        Random rand=new Random();
        doublecount+=1;
        String line;
        double doublevalue=doubletemp;
        //System.out.println("第"+count+"次调用初始值为： "+value);
        double doublenext_value=0;
        String num="";
        double[] double_para={0,1,-1,Double.MAX_EXPONENT,Double.MAX_VALUE,rand.nextDouble(),Double.MIN_EXPONENT,Double.MIN_NORMAL,Double.MIN_VALUE,3.1415926};

        if(doublecount==1000){
            doublecount=1;
            doubletimes=0;
        }
        if(doublecount%100==0) {
            System.out.println("count值###########"+doublecount);
            doublevalue=double_para[(doublecount/100)];
            System.out.println("换新值了"+doublecount+"  "+doublevalue);
        }
        if(doublecount-1<linelist.size()) {               //获取序列
            line=linelist.get((int) (doublecount-1)).toString();
        }
        else {
            line=linelist.get(doublecount%linelist.size()).toString();

        }
        String[] cx=line.substring(1, line.length()-1).split(",");
        for(int l=0;l<cx.length;l++) {
            num=cx[l].trim();
            switch(num) {
                case "1":
                    doublenext_value=doublevalue*doublevalue;

                    break;
                case "2":
                    doublenext_value=doublevalue*2f;

                    break;
                case "3":
                    doublenext_value=doublevalue*-1; //取反
                    break;
                case "4":
                    doublenext_value=(doublevalue+256)/2;
                    break;
                case "5":
                    doublenext_value=(int) Math.sqrt(doublevalue);
                    break;
                default:
                    System.out.println("没有执行到  :"+num);
            }
            doublevalue=doublenext_value;

        }
        doubletemp=doublenext_value;
        if(doublenext_value==0) {
            doubletimes+=1;
            if(doubletimes>=2) {
                doublenext_value+=doubletimes;
            }
        }
        return doublenext_value;
    }

    public static int getInt() {
        Random rand=new Random();
        count+=1;
        String line;
        int value=temp;
        //System.out.println("第"+count+"次调用初始值为： "+value);
        int next_value=0;
        String num="";
        int[] int_para={0,1,-1,Integer.MAX_VALUE,12,45678,Integer.MIN_VALUE,rand.nextInt(),-1234567,-1237,999,567};
        if(count==1000){
            count=1;
            times=0;
        }
        if(count%100==0) {
            Log.e("换新值了",count+"");
            value=int_para[count/100];
            Log.e("换新值了",count+"  "+value);
        }
        if(count-1<linelist.size()) {               //获取序列
            line=linelist.get(count-1).toString();
        }
        else {
            line=linelist.get(count%linelist.size()).toString();
        }
        String[] cx=line.substring(1, line.length()-1).split(",");
        for(int l=0;l<cx.length;l++) {
            num=cx[l].trim();
            switch(num) {
                case "1":
                    next_value=value*value;

                    break;
                case "2":
                    next_value=value*2;

                    break;
                case "3":
                    next_value=~value; //取反

                    break;
                case "4":
                    next_value=(value+1024)/2;
                    break;
                case "5":
                    next_value=(int) Math.sqrt(value);
                    break;
            }
            value=next_value;

        }
        temp=next_value;
        if(next_value==0) {
            times+=1;
            if(times>=2) {
                next_value+=times;
            }
        }
        return next_value;
    }
    public static void makeline () {
        int [] com = {1,2,3,4,5};
        for(int i=1;i<=5;i++) {
            arrangement(i,com);
        }
    }
    public static void arrangement(int k,int []arr){
        if(k == 1){
            for (int i = 0; i < arr.length; i++) {
                tmpArr2.add(arr[i]);
                //System.out.print(tmpArr.toString() + ",");
                linelist.add(tmpArr2.toString());
                tmpArr2.remove((Object)arr[i]);
            }
        }else if(k > 1){
            for (int i = 0; i < arr.length; i++) { //按顺序挑选一个元素
                tmpArr2.add(arr[i]); //添加选到的元素
                arrangement(k - 1, removeArrayElements(arr, tmpArr2.toArray(new Integer[1]))); //没有取过的元素，继续挑选
                tmpArr2.remove((Object)arr[i]);
            }
        }else{
            return ;
        }
    }
    public static int[] removeArrayElements(int[] arr, Integer... elements){
        List<Integer> remainList = new ArrayList<>(arr.length);
        for(int i=0;i<arr.length;i++){
            boolean find = false;
            for(int j=0;j<elements.length;j++){
                if(arr[i] == elements[j]){
                    find = true;
                    break;
                }
            }
            if(!find){ //没有找到的元素保留下来
                remainList.add(arr[i]);
            }
        }
        int[] remainArray = new int[remainList.size()];
        for(int i=0;i<remainList.size();i++){
            remainArray[i] = remainList.get(i);
        }
        return remainArray;
    }


}
