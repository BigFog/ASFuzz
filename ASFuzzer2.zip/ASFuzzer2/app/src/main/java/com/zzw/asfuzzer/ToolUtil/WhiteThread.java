package com.zzw.asfuzzer.ToolUtil;

import android.os.Environment;

import com.zzw.asfuzzer.ServiceUtil.MyApplication;

public class WhiteThread extends Thread {
    public whitelistDatabase whitedbhelper;



    @Override
    public void run() {
        whitedbhelper=new whitelistDatabase(MyApplication.getMcontext());
        whitedbhelper.getWritableDatabase();

    }
}
