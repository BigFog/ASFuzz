package com.zzw.asfuzzer.FuzzUtil;

import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.Parcel;
import android.os.RemoteException;
import android.util.Log;

import com.zzw.asfuzzer.FuzzActivity;
import com.zzw.asfuzzer.LogUtil;
import com.zzw.asfuzzer.ServiceUtil.GetService;
import com.zzw.asfuzzer.ServiceUtil.MyApplication;
import com.zzw.asfuzzer.ToolUtil.whitehelp;

import java.lang.reflect.InvocationTargetException;
import java.security.spec.ECField;
import java.util.ArrayList;
import java.util.List;

public class Fuzz0 implements Runnable {
    private IBinder binder=null;
    private int intercode;
    private String ServiceName=null;
    private String description=null;
    private static Handler handler;

    public List paralist=new ArrayList();

    public  void SetHandler(Handler handler){
        this.handler=handler;

    }

    public Fuzz0(List paralist){

        this.paralist.addAll(paralist);
    }
    /**
     * 集合里面的数据  1，binder 2.服务名  3.接口号 4.接口方法  5.参数1 6.参数2 7.参数3
     * 对于无参数的接口，重复调用。
     */
    public void run(){

        Message message=handler.obtainMessage();
        //1.为避免资源竞争之类，线程暂停0.3秒
        try {
            Thread.sleep(400);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //2.获取binder，为避免binder失活，采取多种binder方案。
        binder=(IBinder) paralist.get(0);
        //3.获取服务名,获取接口描述符。
        ServiceName= (String) paralist.get(1);
        //4.获取接口号
        intercode= (int) paralist.get(2);
        //5.新建data和replay
        Parcel data=Parcel.obtain();
        Parcel reply=Parcel.obtain();

         //7.获取接口描述符。
        try {
            description=binder.getInterfaceDescriptor();
        } catch (RemoteException e) {
            Log.e("error","接口描述符错误");
            e.printStackTrace();
        }
        //8.写入接口描述符

        //9.写入参数其他
        message.arg1=0;
        message.obj="接口名---->"+paralist.get(3)+"  "+"接口号---->"+paralist.get(2)+"  参数为空";
        handler.sendMessage(message);
        LogUtil.e("测试信息","接口名---->"+paralist.get(3)+"  "+"接口号---->"+paralist.get(2));
         for(int i=0;i<50;i++){  //调用50次
             try {

                 //6.生成接口描述符,首先判断是否失活
                 if(binder==null){    //如果binder失活，获取binder
                     Log.d("BINDER","BINDER DEAD!!!");
                     try {
                         binder= GetService.getIBinder(ServiceName);
                     } catch (ClassNotFoundException e) {
                         e.printStackTrace();
                     } catch (NoSuchMethodException e) {
                         e.printStackTrace();
                     } catch (InvocationTargetException e) {
                         e.printStackTrace();
                     } catch (IllegalAccessException e) {
                         e.printStackTrace();
                     }
                 }
                 data.writeInterfaceToken(description);
                 binder.transact(intercode,data,reply,0);
                reply.readException();
                 reply.toString();
             } catch (Exception e) {
                 LogUtil.e("异常信息 fuzz0",MyApplication.getStackTraceInfo(e));
                 LogUtil.e("ERROR 测试参数","接口名-->"+paralist.get(3)+" "+"接口号---->"+paralist.get(2));
                 whitehelp.WriteToWhitelist(paralist.get(3).toString(),ServiceName);
                 LogUtil.e("打印异常","@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@开始打印异常@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
                 LogUtil.e("异常信息",MyApplication.getStackTraceInfo(e));
                 LogUtil.e("打印异常","@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@打印异常结束@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
             }
             finally {
                 data.recycle();
                 reply.recycle();
             }
         }
//        message.arg1=0;
//        message.obj="测试结束！";
//        handler.sendMessage(message);
        whitehelp.WriteToWhitelist(paralist.get(3).toString(),ServiceName);

    }

}
