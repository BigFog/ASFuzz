package com.zzw.asfuzzer.FuzzUtil;

import android.app.SearchManager;
import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.provider.MediaStore;
import android.provider.Settings;
import android.support.annotation.RequiresApi;

import com.zzw.asfuzzer.ServiceUtil.GetService;


import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;



public class DataUtil {

    private static Random random = new Random();


    public static String getRandomString(int length) {
        String base = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";

        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < length; i++) {
            int number = random.nextInt(base.length());
            sb.append(base.charAt(number));
        }
        return sb.toString();
    }
    public static String[] getStrArray(int len) {
        String[] strarray=new String[len];
        for(int i=0;i<len;i++) {
            strarray[i]=getRandomString(random.nextInt(10)+1);
        }
        return strarray;
    }
    public static String getDouble(int exponent, int precision)
    {
        StringBuilder sb = new StringBuilder();
        sb.append((Math.random() < 0.5 ? "+" : "-"));
        sb.append((int)(Math.random() * 10) + ".");
        precision = (int)(Math.random() * precision);
        for (int i = 0; i < precision; i++)
            sb.append((int)(Math.random() * 10));
        sb.append("e" + (Math.random() < 0.5 ? "+" : "-") + ((int)(Math.random() * (exponent + 1))));
        return sb.toString();
    }
    public static List getbinder() throws ClassNotFoundException, NoSuchMethodException, IllegalAccessException, InvocationTargetException {
        IBinder bind;
        List binderlist=new ArrayList();
        Class<?> clazz=Class.forName("android.os.ServiceManager");
        String[] ServiceName = (String[]) clazz.getMethod("listServices").invoke(null);
        for(String SN:ServiceName) {
            Method me = clazz.getMethod("getService", String.class);
            bind=(IBinder) me.invoke(null, SN);
            binderlist.add(bind);
        }
        return binderlist;
    }



    public static boolean getBoolean() {
        return Math.random() < 0.5 ? true : false;
    }
    public static boolean[] getbooleanArray(int len){
        boolean[] bool=new boolean[len];
        for(int i=0;i<len;i++){
            bool[i]=getBoolean();
        }
        return bool;
    }

    public static Intent[] getintentarry(int len){  //数组长度
        Intent[] backintent=new Intent[len];
        for(int i=0;i<len;i++){
            backintent[i]=GetIntent(random.nextInt(48));
        }
        return backintent;
    }
    public static Intent  GetIntent(int i) {  //48
        List intentlist=new ArrayList();
        intentlist.add(new Intent());
        intentlist.add(new Intent(Intent.ACTION_VIEW,Uri.parse("http://www.baidu.com")));//打开百度
        intentlist.add(new Intent(Intent.ACTION_CALL, Uri.parse("tel:17628281627")));//打电话
        intentlist.add(new Intent(Intent.ACTION_CALL_BUTTON));//相当于按拨号键
        Intent intent5 = new Intent(Intent.ACTION_WEB_SEARCH);//搜索内容
        intent5.putExtra(SearchManager.QUERY, "searchString");
        intentlist.add(intent5);
        intentlist.add(new Intent(Intent.ACTION_VIEW,Uri.parse("geo:38.899533,-77.036476")));//显示地图
        Intent intent7=new Intent(Intent.ACTION_VIEW);       //调用发短信程序
        intent7.putExtra("sms_body","The SMS text ceshi");
        intent7.setType("vnd.android-dir/mms-sms");
        intentlist.add(intent7);
        intentlist.add(new Intent(Intent.ACTION_SENDTO,Uri.parse("mailto:3250694303@qq.com")));  //发送邮件
        intentlist.add(new Intent(Settings.ACTION_SETTINGS));            //打开系统设置
        intentlist.add(new Intent(Intent.ACTION_CALL_BUTTON));          //打开通讯录
        intentlist.add(new Intent(Intent.ACTION_CHOOSER));              //activity选择器
        Intent intent12=new Intent(Intent.ACTION_SENDTO,Uri.parse("smsto:17628281627"));  //发送短信
        intent12.putExtra("sms_body","这是一个测试。。。");
        intentlist.add(intent12);

        int requestCode = 1001;
        Intent intent13 = new Intent(Intent.ACTION_GET_CONTENT); //选择一个图片
        intent13.setType("image/*"); // 查看类型，如果是其他类型，比如视频则替换成 video/*，或 */*
        Intent wrapperIntent = Intent.createChooser(intent13, null);
        intentlist.add(wrapperIntent);

        intentlist.add(new Intent(Intent.ACTION_PACKAGE_ADDED,Uri.fromParts("package","com.android.phone",null)));//卸载应用
        intentlist.add(new Intent(Intent.ACTION_CAMERA_BUTTON,null));  //广播打开照相机
        Intent intent16=new Intent(Intent.ACTION_CAMERA_BUTTON,null);     //从gallery选取图片
        intent16.setType("image/*");
        intent16.setAction(Intent.ACTION_GET_CONTENT);
        intentlist.add(intent16);
        intentlist.add(new Intent(MediaStore.Audio.Media.RECORD_SOUND_ACTION));   //打开录音机
        intentlist.add(new Intent(Intent.ACTION_VIEW,Uri.parse("market://details?id=app_id")));  //显示应用详细列表
        intentlist.add(new Intent(Intent.ACTION_VIEW,Uri.parse("market://search?q=com.android.phone"))); //搜索应用
        Intent intent20=new Intent();
        intent20.setAction(Intent.ACTION_GET_CONTENT);
        intent20.setType("vnd.android.cursor.item/phone");    //打开联系人列表
        intentlist.add(intent20);
        intentlist.add(new Intent(Settings.ACTION_APN_SETTINGS));  //打开vpn
        intentlist.add(new Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS));   //vpn设置
        intentlist.add(new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS));
        intentlist.add(new Intent(Settings.ACTION_APPLICATION_SETTINGS));
        intentlist.add(new Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS));
        intentlist.add(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
        intentlist.add(new Intent(Settings.ACTION_DATA_ROAMING_SETTINGS));
        intentlist.add(new Intent(Settings.ACTION_DATE_SETTINGS));
        intentlist.add(new Intent(Settings.ACTION_DISPLAY_SETTINGS));
        intentlist.add(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS));
        intentlist.add(new Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS));
        intentlist.add(new Intent(Settings.ACTION_LOCALE_SETTINGS));
        intentlist.add(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
        intentlist.add(new Intent(Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS));
        intentlist.add(new Intent(Settings.ACTION_MEMORY_CARD_SETTINGS));
        intentlist.add(new Intent(Settings.ACTION_NETWORK_OPERATOR_SETTINGS));
        intentlist.add(new Intent(Settings.ACTION_QUICK_LAUNCH_SETTINGS));
        intentlist.add(new Intent(Settings.ACTION_SECURITY_SETTINGS));
        intentlist.add(new Intent(Settings.ACTION_SETTINGS));
        intentlist.add(new Intent(Settings.ACTION_SOUND_SETTINGS));
        intentlist.add(new Intent(Settings.ACTION_SYNC_SETTINGS));
        intentlist.add(new Intent(Settings.ACTION_USER_DICTIONARY_SETTINGS));
        intentlist.add(new Intent(Settings.ACTION_WIFI_IP_SETTINGS));
        intentlist.add(new Intent(Settings.ACTION_WIFI_SETTINGS));
        intentlist.add(new Intent(Settings.ACTION_WIRELESS_SETTINGS));
        intentlist.add(new Intent(Intent.ACTION_PICK));
        intentlist.add(new Intent(Intent.ACTION_EDIT));
        intentlist.add(new Intent(Intent.ACTION_CREATE_SHORTCUT));
        return (Intent) intentlist.get(i);
    }
    public static char getChar()
    {
         char[] chars ="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".toCharArray();
        return chars[(int)(Math.random() * 62)];
    }
    public static Uri GetUri(){
//        List Urilist=new ArrayList();  //uri  22
//        Urilist.add(Uri.parse("http://www.baidu.com"));
//        Urilist.add(Uri.parse("http://maps.google.com/maps?f=dsaddr=startLat%20startLng&daddr=endLat%20endLng&hl=en"));
//        Urilist.add(Uri.parse("geo:38.899533,-77.036476"));
//        Urilist.add(Uri.parse("tel:10086"));
//        Urilist.add(Uri.parse("smsto:17628281627"));
//        Urilist.add(Uri.parse("content://media/external/images/media/23"));
//        Urilist.add(Uri.parse("mailto:3250694303@qq.com"));
//        Urilist.add(Uri.parse("market://details?id=app_id"));
//        Urilist.add(Uri.parse("market://search?q=pname:pkg_name"));
//        Urilist.add(Uri.parse("content://contacts/people"));
//        Urilist.add(Uri.parse("content://contacts/people/5"));
//        Urilist.add(Uri.parse("content://media/external"));
//        Urilist.add(Uri.parse("content://media/external/images/media/4"));
//        Urilist.add(Uri.parse("file://system/media/audio/alarms"));
//        Urilist.add(Uri.parse("content://com.android.contacts/data/phones"));
//        Urilist.add(Uri.parse("content://com.android.contacts/contacts"));
//        Urilist.add(Uri.parse("content://com.android.contacts/data/emails"));
//        Urilist.add(Uri.parse("MediaStore.Audio.Media.EXTERNAL_CONTENT_URI"));
//        Urilist.add(MediaStore.Audio.Media.INTERNAL_CONTENT_URI);
//        Urilist.add(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI);
//        Urilist.add(Uri.parse("content://sms/outbox"));
//        Urilist.add(MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
//        return (Uri) Urilist.get(i);
        return null;
    }


 public static Bundle GetBundle() throws ClassNotFoundException, NoSuchMethodException, IllegalAccessException, InvocationTargetException {

        Bundle bundle=new Bundle();

//            bundle.putBundle("key2",bundle);
//
//
//

//        bundle.putCharArray("char",chararray);
//        bundle.putFloat("key",Float.MAX_VALUE);
//        float []floatarray=new float[]{1,-1,Float.MAX_VALUE,Float.MIN_VALUE};
//        bundle.putFloatArray("float",floatarray);
//        bundle.putInt("int",Integer.MAX_VALUE);
//        int []intarray=new int[]{Integer.MAX_VALUE,1234567,Integer.MIN_VALUE};
//        bundle.putIntArray("int",intarray);
//        bundle.putShort("short",Short.MAX_VALUE);
//        short [] shortarray=new short[]{0,Short.MAX_VALUE,Short.MIN_VALUE};
//        bundle.putShortArray("short",shortarray);
//        bundle.putString("string",getRandomString(8));
//        ArrayList str_para=new ArrayList(5);
//        str_para.add(" ");
//        str_para.add("abcd");
//        str_para.add(getRandomString(4));
//        str_para.add(getRandomString(6));
//        bundle.putStringArrayList("String",str_para);
//        bundle.putBoolean("flag",getBoolean());
//        boolean [] bool1=new boolean[]{getBoolean(),getBoolean(),getBoolean()};
//        bundle.putBooleanArray("flag",bool1);
//        bundle.putDouble("double",Double.MAX_VALUE);
//        double []doublearaay=new double[]{1,-1,Double.MAX_EXPONENT,Double.MAX_VALUE};
//        bundle.putDoubleArray("double",doublearaay);
//        bundle.putLong("long",Long.MAX_VALUE);
//        long []longarray=new long[]{1,-1,Long.MAX_VALUE,Long.MIN_VALUE};
//
//        bundle.putChar("key0",'a');


        return bundle;
 }
      public static List getList(int len){
        List list=new ArrayList();  //该list有30个内容
        list.add(1);
        list.add(0);
        list.add(-1);
        list.add(Integer.MAX_VALUE);
        list.add(Integer.MIN_VALUE);
        list.add(Long.MAX_VALUE);
        list.add(Long.MIN_VALUE);
        list.add(Float.MAX_VALUE);
        list.add(Float.MIN_VALUE);
        list.add(Float.MIN_NORMAL);
        list.add(Double.MAX_EXPONENT);
        list.add(Double.MAX_VALUE);
        list.add(Double.MIN_EXPONENT);
        list.add(Double.MIN_NORMAL);
        list.add(Byte.MAX_VALUE);
        list.add(Byte.MIN_VALUE);
        list.add("abcdefgh");
        list.add(true);
        list.add(false);
        list.add(789);
        list.add('a');
        list.add(random.nextInt());
        list.add(random.nextDouble());
        list.add(random.nextBoolean());
        list.add(random.nextFloat());
        list.add(random.nextLong());
        list.add(" ");
        list.add(3.1415926);
        list.add(new HashMap<String,Integer>());
        list.add(random.nextGaussian());
        List backlist=new ArrayList();
        for(int i=0;i<len;i++){
              backlist.add(list.get(i));
          }
        return backlist;
      }
      public static String StringArrayToString(String[] st){
        StringBuilder sb=new StringBuilder();
        for(String x:st){
            sb.append(x+" ");
        }
        return sb.toString();
      }

      public static  Map  GetMap(int len){

        List listmap=new ArrayList();
        listmap.add(123);                 //21个
        listmap.add(Integer.MIN_VALUE);
        listmap.add("abcd");
        listmap.add(Float.MAX_VALUE);
        listmap.add(Byte.MIN_VALUE);
        listmap.add(true);
        listmap.add(Long.MAX_VALUE);
        listmap.add(false);
        listmap.add(Integer.MAX_VALUE);
        listmap.add(Long.MIN_VALUE);
        listmap.add(Double.MAX_VALUE);
        listmap.add(Byte.MAX_VALUE);
        listmap.add(Float.MIN_VALUE);
        listmap.add(random.nextInt());
        listmap.add(random.nextDouble());
        listmap.add(random.nextBoolean());
        listmap.add(random.nextFloat());
        listmap.add(random.nextLong());
        listmap.add(1234567);
        listmap.add("sdjhjfkhsjklfhdsklhl");
        listmap.add(Double.MIN_VALUE);

        Map backmap=new HashMap();
        for(int i=0;i<len;i++){

            backmap.put("key"+i,listmap.get(i));
        }
        return backmap;
      }

      public static ComponentName getComPonentname(int i){
        List componentList=new ArrayList();   //31
          componentList.add(new ComponentName("com.android.providers.contacts", "com.android.providers.contacts.debug.ContactsDumpActivity"));
          componentList.add(new ComponentName("com.android.captiveportallogin","com.android.captiveportallogin.CaptivePortalLoginActivity"));
          componentList.add(new ComponentName("com.android.providers.calendar","com.android.providers.calendar.CalendarDebugActivity"));
          componentList.add(new ComponentName("com.android.wallpapercropper","com.android.wallpapercropper.WallpaperCropActivity"));
          componentList.add(new ComponentName("com.android.wallpapercropper","com.android.wallpapercropper.WallpaperCropActivity"));
          componentList.add(new ComponentName("com.android.htmlviewer","com.android.htmlviewer.HTMLViewerActivity"));
          componentList.add(new ComponentName("com.android.certinstaller","com.android.certinstaller.CertInstallerMain"));
          componentList.add(new ComponentName("com.android.keychain","com.android.keychain.KeyChainActivity"));
          componentList.add(new ComponentName("com.android.wallpaper.livepicker","com.android.wallpaper.livepicker.LiveWallpaperActivity"));
          componentList.add(new ComponentName("com.android.wallpaper.livepicker","com.android.wallpaper.livepicker.LiveWallpaperChange"));
          componentList.add(new ComponentName("com.android.phone","com.android.phone.settings.VoicemailSettingsActivity"));
          componentList.add(new ComponentName("com.android.phone","com.android.phone.settings.PhoneAccountSettingsActivity"));
          componentList.add(new ComponentName("com.android.phone","com.android.phone.settings.AccessibilitySettingsActivity"));
          componentList.add(new ComponentName("com.android.phone","com.android.phone.CallFeaturesSetting"));
          componentList.add(new ComponentName("com.android.phone","com.android.services.telephony.sip.SipPhoneAccountSettingsActivity"));
          componentList.add(new ComponentName("com.android.phone","com.android.phone.EmergencyCallbackModeExitDialog"));
          componentList.add(new ComponentName("com.android.phone","com.android.phone.SimContacts"));
          componentList.add(new ComponentName("com.android.systemui","com.android.systemui.DessertCase"));
          componentList.add(new ComponentName("com.android.bluetooth","com.android.bluetooth.opp.BluetoothOppLauncherActivity"));
          componentList.add(new ComponentName("com.android.captiveportallogin","com.android.captiveportallogin.CaptivePortalLoginActivity"));
          componentList.add(new ComponentName("com.android.systemui","com.android.systemui.Somnambulator"));
          componentList.add(new ComponentName("com.android.phone","com.android.phone.settings.fdn.FdnList"));
          componentList.add(new ComponentName("com.android.phone","com.android.phone.CdmaCallOptions"));
          componentList.add(new ComponentName("com.android.phone","com.android.phone.MobileNetworkSettings"));
          componentList.add(new ComponentName("com.android.phone","com.android.phone.EnableIccPinScreen"));
          componentList.add(new ComponentName("com.android.phone","com.android.services.telephony.sip.SipSettings"));
          componentList.add(new ComponentName("com.android.phone","com.android.phone.settings.fdn.FdnSetting"));
          componentList.add(new ComponentName("com.android.phone","com.android.phone.ChangeIccPinScreen"));
          componentList.add(new ComponentName("com.android.phone","com.android.phone.NetworkSetting"));
          componentList.add(new ComponentName("com.android.keychain","com.android.keychain.KeyChainService"));
          componentList.add(new ComponentName("com.android.providers.media","com.android.providers.media.MediaScannerService"));
          return (ComponentName) componentList.get(i);
    }
    public static ComponentName[] getComponentArray(int len){
        ComponentName[] componentArray=new ComponentName[len];
        for(int i=0;i<len;i++){
            componentArray[i]=getComPonentname(i);
        }
        return componentArray;
    }
    public static  int getRandomint(int max,int min)
    {
        return (int) ((Math.random() * (max - min + 1)) + min);
    }


    public static byte[] getByte(int i){
        byte []array=getbyteArry((i+1)%64);

        return array;
    }
    public static  byte[] getbyteArry(int len) {

        Random rand=new Random();
        byte []array=new byte[len];
        rand.nextBytes(array);
       // byte[] byte_para={-12,12,1,-1,Byte.MAX_VALUE,Byte.MIN_VALUE,12,103,-12,-101,};
        return array;
    }

    public static float[] getfloatarray(int i){
        return getfloatarray1((i+1)%64);
    }
    public static float[] getfloatarray1(int len) {
        float min = -1000f;
        float max = 1000f;
        Random rand=new Random();
        float[] floatarray=new float[len];
        for(int i=0;i<len;i++) {
            floatarray[i]= min+ rand.nextFloat()*(max-min);
        }
        return floatarray;
    }
    public static byte getBytevalue(int len) {
        byte[] x=new byte[Byte.MAX_VALUE-Byte.MIN_VALUE];
        int count=0;
        for(int i=Byte.MIN_VALUE;i<Byte.MAX_VALUE;i++) {
            x[count]=(byte)i;
            count+=1;
        }
        return x[len];
    }
}
