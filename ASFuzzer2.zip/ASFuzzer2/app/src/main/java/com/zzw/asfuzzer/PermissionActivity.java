package com.zzw.asfuzzer;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.zzw.asfuzzer.ServiceUtil.GetContext;

public class PermissionActivity extends AppCompatActivity {
    String[] permission = new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.CAMERA,
            Manifest.permission.GET_ACCOUNTS, Manifest.permission.READ_CALENDAR,
            Manifest.permission.CALL_PHONE, Manifest.permission.ACCESS_COARSE_LOCATION,Manifest.permission.WRITE_SECURE_SETTINGS,
            Manifest.permission.RECORD_AUDIO, Manifest.permission.BODY_SENSORS, Manifest.permission.SEND_SMS};
    int requestcode = 100;
    boolean flag=false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permission);
        for (int i = 0; i < permission.length; i++) {
            if (ContextCompat.checkSelfPermission(PermissionActivity.this, permission[i]) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(PermissionActivity.this, new String[]{permission[i]}, 100);
            }
        }
        Intent intent = new Intent(PermissionActivity.this, MainActivity.class);
        startActivity(intent);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == requestcode) {
            for (int i = 0; i < grantResults.length; i++) {
                if (grantResults.length > 0 && grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                    GetContext.toastNews("congratulation");
                }
                else{
                    flag=true;
                }

            }
        }
        if(flag=true){
            Intent intent = new Intent(PermissionActivity.this, MainActivity.class);
            startActivity(intent);
        }
    }
}
