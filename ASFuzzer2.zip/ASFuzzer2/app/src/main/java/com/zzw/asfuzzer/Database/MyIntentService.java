package com.zzw.asfuzzer.Database;

import android.app.IntentService;
import android.content.Intent;
import android.os.Environment;


import com.zzw.asfuzzer.ServiceUtil.GetContext;
import com.zzw.asfuzzer.ServiceUtil.GetService;
import com.zzw.asfuzzer.ToolUtil.whitelistDatabase;

import java.lang.reflect.InvocationTargetException;

import static com.zzw.asfuzzer.ServiceUtil.GetService.GetTableName;


public class MyIntentService extends IntentService {
    public DataBaseHelper dbhelper;
    public static GetService getS=new GetService();


    public MyIntentService() {
        super("MyIntentService");
    }

    @Override
    protected void onHandleIntent( Intent intent) {
        GetContext.toastNews("数据库开始建立");

        dbhelper=new DataBaseHelper(this,"ASFuzzer.db",null,1);
        try {
            GetTableName();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        dbhelper.getReadableDatabase();
        Insertdata insert=new Insertdata();

        try {
            insert.InsertPara(dbhelper);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }


       GetContext.toastNews("数据库建立成功");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        GetContext.toastNews("服务shutdown");
    }
}
