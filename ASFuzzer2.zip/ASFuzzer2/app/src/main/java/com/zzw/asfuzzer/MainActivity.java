package com.zzw.asfuzzer;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.zzw.asfuzzer.FuzzUtil.Getlistdata;
import com.zzw.asfuzzer.ServiceUtil.GetService;
import com.zzw.asfuzzer.ToolUtil.WhiteThread;

import java.lang.reflect.InvocationTargetException;

public class MainActivity extends AppCompatActivity {
    private String data[];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        try {
            show_list();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
        WhiteThread startWhite=new WhiteThread();
        new Thread(startWhite).start();


    }



    public void show_list() throws ClassNotFoundException, NoSuchMethodException, IllegalAccessException, InvocationTargetException {
        Class<?> ss = Class.forName("android.os.ServiceManager");
        data=GetService.GetServiceName(ss);
        for(int i=0;i<data.length;i++){
            data[i]=i+"  "+data[i];
        }
        ArrayAdapter<String> adapter=new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_list_item_1, data);
        ListView listview=findViewById(R.id.listshowService);
        listview.setAdapter(adapter);
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String servicename=data[position];
                Intent intent=new Intent(MainActivity.this, FuzzActivity.class);
                intent.putExtra("ServiceName",servicename.split(" ")[2]);

                startActivity(intent);
            }
        });

    }
}
