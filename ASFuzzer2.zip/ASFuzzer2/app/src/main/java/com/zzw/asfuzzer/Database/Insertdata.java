package com.zzw.asfuzzer.Database;


import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.IBinder;
import android.os.RemoteException;

import com.zzw.asfuzzer.ServiceUtil.GetService;


import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;

public class Insertdata {

    public IBinder bind;
    public String interfaceDescribtion=null;
    public Class<?> clazz=null;
    public static HashMap<String, Integer> InterfaceCodemap;
    public int num=0;
    public void InsertPara(DataBaseHelper dbhelper) throws ClassNotFoundException, NoSuchMethodException, IllegalAccessException, InvocationTargetException {
        SQLiteDatabase db=dbhelper.getReadableDatabase();

        clazz = Class.forName("android.os.ServiceManager");
        String[] Service_Name = GetService.GetServiceName(clazz);
        for (String SN:Service_Name){
            Class<?> cla=null;
            InterfaceCodemap=GetService.GetInterfaceCode(SN);
            ContentValues values=new ContentValues();
            bind=GetService.getIBinder(SN);
            try{
                interfaceDescribtion=bind.getInterfaceDescriptor();
                cla=Class.forName(interfaceDescribtion);
            }
          catch (RemoteException e) {
                e.printStackTrace();
                continue;
            }
            finally {
                if(interfaceDescribtion==null || cla==null)
                {
                    continue;
                }
                else{
                    Method[] methods=cla.getDeclaredMethods();
                    for(Method me:methods){
                        values.put("InterfaceName",me.getName());
                        values.put("interfaceCode",InterfaceCodemap.get(me.getName()));
                        values.put("interfaceDescribtion",interfaceDescribtion);
                        Class<?>[] para=me.getParameterTypes();
                        for(int i=0;i<para.length;i++){
                            String pa=para[i].getName();
                            values.put("para"+i,pa);
                        }
                        if(SN.contains(".")){
                            SN=SN.replace(".","0");
                        }
                        db.insert(SN,null,values);
                        values.clear();
                    }
                    num+=1;
                    continue;
                }
            }
        }
    }
}
