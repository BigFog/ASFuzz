package com.zzw.asfuzzer.ToolUtil;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Environment;
import android.support.annotation.Nullable;

import com.zzw.asfuzzer.ServiceUtil.GetContext;
import com.zzw.asfuzzer.ServiceUtil.GetService;
import com.zzw.asfuzzer.ServiceUtil.MyApplication;

import java.lang.reflect.InvocationTargetException;

public class whitelistDatabase extends SQLiteOpenHelper {
    public static final int  version=1;
    public static whitelistDatabase dbhelper;
    public static final String  pathname= Environment.getExternalStorageDirectory()+"/WHITElist.db";
            //CREATE_WHITELIST="create table WhiteList ("+"id integer primary key autoincrement,"+",";

   // private static Context context;//= MyApplication.getMcontext();
    public  static whitelistDatabase getdbhelper(Context context){
        if(dbhelper==null) {
            dbhelper = new whitelistDatabase(context);
        }
        return dbhelper;
    }
    public whitelistDatabase(Context context) {
        super(context, pathname, null, version);
       // mcontext=context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        Class<?> clazz = null;
        String [] servicename=null;
        try {
            clazz = Class.forName("android.os.ServiceManager");
            servicename= GetService.GetServiceName(clazz);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
        db.beginTransaction();
        for(String SN:servicename){
            if(SN.contains(".")){
                SN=SN.replace(".","0");
            }
            String chartname="create table " +SN+ "("+"id integer primary key autoincrement,"+"interMethodName text)";
                    //+"interMethodNumber integer,"+"isHavetest integer
            db.execSQL(chartname);
        }
        db.setTransactionSuccessful();
        db.endTransaction();


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

}
