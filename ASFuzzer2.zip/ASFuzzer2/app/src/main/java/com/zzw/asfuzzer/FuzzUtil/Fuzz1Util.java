package com.zzw.asfuzzer.FuzzUtil;

import android.util.Log;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Fuzz1Util {
    static List list=new ArrayList();
    static int temp=0;
    static int count=0;
    public static int times=0;
    static long longtemp=0;
    static int longcount=0;
    static int longtimes=0;

    static float floattemp=0;
    static int floatcount=0;
    static int floattimes=0;

    static double doubletemp=0;
    static int doublecount=0;
    static int doubletimes=0;
    private static ArrayList<Integer> tmpArr = new ArrayList<>();
    public static void makeline () {
        int [] com = {1,2,3,4,5};
        for(int i=1;i<=5;i++) {
            arrangement(i,com);
        }
    }
    public static int getInt() {
        Random rand=new Random();
        count+=1;
        String line;
        int value=temp;
        //System.out.println("第"+count+"次调用初始值为： "+value);
        int next_value=0;
        String num="";
        int[] int_para={0,1,-1,Integer.MAX_VALUE,12,45678,Integer.MIN_VALUE,rand.nextInt(),-1234567,-1237,999,567};
        if(count==1000){
            count=1;
            times=0;
        }
        if(count%100==0) {
            Log.e("换新值了",count+"");
            value=int_para[count/100];
            Log.e("换新值了",count+"  "+value);
        }
        if(count-1<list.size()) {               //获取序列
            line=list.get(count-1).toString();
        }
        else {
            line=list.get(count%list.size()).toString();
        }
        String[] cx=line.substring(1, line.length()-1).split(",");
        for(int l=0;l<cx.length;l++) {
            num=cx[l].trim();
            switch(num) {
                case "1":
                    next_value=value*value;
                    break;
                case "2":
                    next_value=value*2;
                    break;
                case "3":
                    next_value=~value; //取反
                    break;
                case "4":
                    next_value=(value+1024)/2;
                    break;
                case "5":
                    next_value=(int) Math.sqrt(value);
                    break;
            }
            value=next_value;
        }
        temp=next_value;
        if(next_value==0) {
            times+=1;
            if(times>=2) {
                next_value+=times;
            }
        }
        return next_value;
    }
    public static long[] getLongarray(int len){
        long[] backlong=new long [len];
        for(int i=0;i<len;i++){
            backlong[i]=getLong();
        }
        return backlong;
    }
    public static long getLong() {

        Random rand=new Random();
        longcount+=1;
        String line;

        long longvalue=longtemp;
        //System.out.println("第"+count+"次调用初始值为： "+value);
        long longnext_value=0;
        String num="";
        long[] long_para={0,1,-1,6565596567576575478L,Long.MAX_VALUE,57657,Long.MIN_VALUE,-8999999999999999999L,999999999,rand.nextLong(),5677};
        if(longcount==1000){
            longcount=1;
            longtimes=0;
        }
        if(longcount%100==0) {
            System.out.println("count值###########"+longcount);
            longvalue=long_para[(longcount/100)];
            System.out.println("换新值了"+longcount+"  "+longvalue);
        }
        if(longcount-1<list.size()) {               //获取序列
            line=list.get((int) (longcount-1)).toString();
        }
        else {
            line=list.get(longcount%list.size()).toString();
        }
        String[] cx=line.substring(1, line.length()-1).split(",");
        for(int l=0;l<cx.length;l++) {
            num=cx[l].trim();
            switch(num) {
                case "1":
                    longnext_value=longvalue*longvalue;
                    break;
                case "2":
                    longnext_value=longvalue*2;

                    break;
                case "3":
                    longnext_value=~longvalue; //取反

                    break;
                case "4":
                    longnext_value=(longvalue+123456789)/2;
                    break;
                case "5":
                    longnext_value=(int) Math.sqrt(longvalue);
                    break;
                default:
                    System.out.println("没有执行到  :"+num);
            }
            longvalue=longnext_value;

        }
        longtemp=longnext_value;
        // System.out.println("结果:"+next_value);
        if(longnext_value==0) {
            longtimes+=1;
            if(longtimes>=2) {
                longnext_value+=longtimes;
            }
        }
        return longnext_value;
    }
    public static double[] getDoubleArry1(int len){
        double[] backdouble=new double[len];
        for(int i=0;i<len;i++){
            backdouble[i]=getdouble();
        }
        return backdouble;
    }
    public static void arrangement(int k,int []arr){
        if(k == 1){
            for (int i = 0; i < arr.length; i++) {
                tmpArr.add(arr[i]);
                //System.out.print(tmpArr.toString() + ",");
                list.add(tmpArr.toString());
                tmpArr.remove((Object)arr[i]);
            }
        }else if(k > 1){
            for (int i = 0; i < arr.length; i++) { //按顺序挑选一个元素
                tmpArr.add(arr[i]); //添加选到的元素
                arrangement(k - 1, removeArrayElements(arr, tmpArr.toArray(new Integer[1]))); //没有取过的元素，继续挑选
                tmpArr.remove((Object)arr[i]);
            }
        }else{
            return ;
        }
    }
    /**
     * 移除数组某些元素（不影响原数组）
     * @param arr 数组
     * @param elements 待移除的元素
     * @return 剩余元素组成的新数组
     */
    public static int[] removeArrayElements(int[] arr, Integer... elements){
        List<Integer> remainList = new ArrayList<>(arr.length);
        for(int i=0;i<arr.length;i++){
            boolean find = false;
            for(int j=0;j<elements.length;j++){
                if(arr[i] == elements[j]){
                    find = true;
                    break;
                }
            }
            if(!find){ //没有找到的元素保留下来
                remainList.add(arr[i]);
            }
        }
        int[] remainArray = new int[remainList.size()];
        for(int i=0;i<remainList.size();i++){
            remainArray[i] = remainList.get(i);
        }
        return remainArray;
    }

    public static float getfloat() {

        Random rand=new Random();
        floatcount+=1;
        String line;

        float floatvalue=floattemp;
        //System.out.println("第"+count+"次调用初始值为： "+value);
        float floatnext_value=0;
        String num="";
        float[] float_para={0,1,-1,Float.MAX_VALUE,Float.MIN_VALUE,Float.MIN_NORMAL,Float.MAX_EXPONENT,Float.MIN_EXPONENT,rand.nextFloat(),765768f};
        if(floatcount==1000){
            floatcount=1;
            floattimes=0;
        }
        if(floatcount%100==0) {
            System.out.println("count值###########"+floatcount);
            floatvalue=float_para[(floatcount/100)];
            System.out.println("换新值了"+floatcount+"  "+floatvalue);
        }
        if(floatcount-1<list.size()) {               //获取序列
            line=list.get((int) (floatcount-1)).toString();
        }
        else {
            line=list.get(floatcount%list.size()).toString();
        }
        String[] cx=line.substring(1, line.length()-1).split(",");
        for(int l=0;l<cx.length;l++) {
            num=cx[l].trim();
            switch(num) {
                case "1":
                    floatnext_value=floatvalue*floatvalue;
                    break;
                case "2":
                    floatnext_value=floatvalue*2f;

                    break;
                case "3":
                    floatnext_value=floatvalue*-1; //取反

                    break;
                case "4":
                    floatnext_value=(floatvalue+256)/2;
                    break;
                case "5":
                    floatnext_value=(int) Math.sqrt(floatvalue);
                    break;
                default:
                    System.out.println("没有执行到  :"+num);
            }
            floatvalue=floatnext_value;

        }
        floattemp=floatnext_value;
        if(floatnext_value==0) {
            floattimes+=1;
            if(floattimes>=2) {
                floatnext_value+=floattimes;
            }
        }
        return floatnext_value;
    }
    public static double getdouble() {

        Random rand=new Random();
        doublecount+=1;
        String line;

        double doublevalue=doubletemp;
        //System.out.println("第"+count+"次调用初始值为： "+value);
        double doublenext_value=0;
        String num="";
        double[] double_para={0,1,-1,Double.MAX_EXPONENT,Double.MAX_VALUE,rand.nextDouble(),Double.MIN_EXPONENT,Double.MIN_NORMAL,Double.MIN_VALUE,3.1415926};

        if(doublecount==1000){
            doublecount=1;
            doubletimes=0;
        }
        if(doublecount%100==0) {
            System.out.println("count值###########"+doublecount);
            doublevalue=double_para[(doublecount/100)];
            System.out.println("换新值了"+doublecount+"  "+doublevalue);
        }
        if(doublecount-1<list.size()) {               //获取序列
            line=list.get((int) (doublecount-1)).toString();
        }
        else {
            line=list.get(doublecount%list.size()).toString();

        }
        String[] cx=line.substring(1, line.length()-1).split(",");
        for(int l=0;l<cx.length;l++) {
            num=cx[l].trim();
            switch(num) {
                case "1":
                    doublenext_value=doublevalue*doublevalue;

                    break;
                case "2":
                    doublenext_value=doublevalue*2f;

                    break;
                case "3":
                    doublenext_value=doublevalue*-1; //取反
                    break;
                case "4":
                    doublenext_value=(doublevalue+256)/2;
                    break;
                case "5":
                    doublenext_value=(int) Math.sqrt(doublevalue);
                    break;
                default:
                    System.out.println("没有执行到  :"+num);
            }
            doublevalue=doublenext_value;

        }
        doubletemp=doublenext_value;
        if(doublenext_value==0) {
            doubletimes+=1;
            if(doubletimes>=2) {
                doublenext_value+=doubletimes;
            }
        }
        return doublenext_value;
    }
    public static int[] getIntarray(int len) {
        int[] intarray=new int[len];
        Random rand=new Random();
        count+=1;
        String line;
        int value=temp;
        int next_value = 0;
        int max=1000,min=-1000;
        String num="";
        int[] int_para={0,1,-1,Integer.MAX_VALUE,1234567,45678,Integer.MIN_VALUE,rand.nextInt(),-1234567,-1237,99999999,567};
        if(count<11) {
            value=int_para[count];
        }
        else {
            value=int_para[count%11];
        }
        if(count%100==0) {
            count=1;
        }
        if(count-1<list.size()) {               //获取序列
            line=list.get(count-1).toString();
        }
        else {
            line=list.get(count%list.size()).toString();
        }
        for(int w=0;w<len;w++) {
            String[] cx = line.substring(1, line.length() - 1).split(",");
            for (int l = 0; l < cx.length; l++) {
                num = cx[l].trim();
                switch (num) {
                    case "1":
                        next_value = value * value;
                        break;
                    case "2":
                        next_value = value * 2;
                        break;
                    case "3":
                        next_value = ~value; //取反
                        break;
                    case "4":
                        next_value = (value + 256) / 2;
                        break;
                    case "5":
                        next_value = (int) Math.sqrt(value);
                        break;
                    default:
                        System.out.println("没有执行到  :" + num);

                }
                value = next_value;
            }
            if (next_value == 0) {
                times += 1;
                if (times >= 2) {
                    next_value += times;
                }
            }
            intarray[w] = next_value;

        }
        return intarray;
    }

}




