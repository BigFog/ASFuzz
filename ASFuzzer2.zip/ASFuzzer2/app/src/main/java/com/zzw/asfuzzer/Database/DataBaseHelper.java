package com.zzw.asfuzzer.Database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


import com.zzw.asfuzzer.ServiceUtil.GetContext;

import java.util.List;

public class DataBaseHelper extends SQLiteOpenHelper {
    private Context mcontext;
    public List<String> table1;
    public TableName list1;
    public DataBaseHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
        mcontext=context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        list1=new TableName();
        table1=list1.getTable();

        db.beginTransaction();
        for(String  s:table1)
             db.execSQL(s);
        db.setTransactionSuccessful();
        GetContext.toastNews("数据库创建完成");
        db.endTransaction();


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
