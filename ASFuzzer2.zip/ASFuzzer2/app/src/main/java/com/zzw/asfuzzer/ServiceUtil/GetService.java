package com.zzw.asfuzzer.ServiceUtil;




import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;


import com.zzw.asfuzzer.Database.TableName;


import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import static android.os.IBinder.INTERFACE_TRANSACTION;

public class GetService {
    public static String interfaceDescribtion = null;

    public static IBinder bind;
    public static HashMap<String, Integer> MaxParamap;
    public static int MaxParaMax = 0;

    public static List<String> list = new ArrayList<>();

    public static String[] Service_Name;


    /**
     * 获取服务名
     *
     * @param clazz
     * @return
     * @throws InvocationTargetException
     */
    public static String[] GetServiceName(Class<?> clazz) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {

        String[] ServiceName = (String[]) clazz.getMethod("listServices").invoke(null);
        System.out.println("服务总数为：" + ServiceName.length); //服务个数
        return ServiceName;  //返回服务数组
    }


    /**
     * 利用反射获取服务额IBinder接口
     *
     * @param Servicename
     * @return
     * @throws InvocationTargetException
     */

    public static IBinder getIBinder(String Servicename) throws ClassNotFoundException, NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        Class<?> ss = Class.forName("android.os.ServiceManager");
        Method me = ss.getMethod("getService", String.class);
        return (IBinder) me.invoke(null, Servicename);
    }


    /**
     * 获取接口描述符
     *
     * @param
     * @return 返回接口描述符
     * @throws RemoteException
     */
    public static String getInterfacedescription(IBinder serHandle) throws RemoteException {
        Parcel data = Parcel.obtain();
        Parcel reply = Parcel.obtain();
        serHandle.transact(INTERFACE_TRANSACTION, data, reply, 0);
        String interfacename = reply.readString();
        data.recycle();
        reply.recycle();
        return interfacename;
    }



    public static HashMap GetInterfaceCode(String SN) throws ClassNotFoundException, NoSuchMethodException, IllegalAccessException, InvocationTargetException {
        HashMap<String, Integer> CodeMap = new HashMap<>();
        Class<?> clazz1=null;
        bind = GetService.getIBinder(SN);
        try {
            interfaceDescribtion = bind.getInterfaceDescriptor();
            clazz1 = Class.forName(interfaceDescribtion);
            if (interfaceDescribtion == null || clazz1 == null) {
                return CodeMap;
            }
            Field[] field = clazz1.getDeclaredFields();
            if (field.length == 0) {
                clazz1 = Class.forName(interfaceDescribtion + "$Stub");
                field = clazz1.getDeclaredFields();
                int a=0;
                if(field[a].toString().contains("TRANSACTION"))
                {
                    a=0;
                }
                else{
                    a=1;
                }
                for (int i=a; i < field.length; i++) {
                    Field me = field[i];
                    me.setAccessible(true);
                    int b = (int) me.get(clazz1);
                    CodeMap.put(me.toString().split("\\_")[1], b);
                }
            } else {
                for (int i = 0; i < field.length; i++) {
                    Field me = field[i];
                    me.setAccessible(true);
                    if (me.toString().contains("TRANSACTION")) {
                        int a = (int) me.get(clazz1);
                        try {
                            CodeMap.put(DealTractString(me.toString()), a);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return CodeMap;
    }

    public static String DealTractString(String st) {
        ArrayList<String> strArray = new ArrayList<>();
        String[] st1 = st.split("\\.");
        st1 = st1[st1.length - 1].split("\\_");
        Collections.addAll(strArray, st1);

        boolean ele = strArray.contains("TRANSACTION");
        if (ele) {
            strArray.remove("TRANSACTION");
        }
        String result = strArray.get(0).toLowerCase();
        for (int i = 1; i < strArray.size(); i++) {
            String x = strArray.get(i);
            result += x.charAt(0) + x.substring(1).toLowerCase();
        }
        return result;
    }


    public static HashMap getMaxparaNum() throws ClassNotFoundException, NoSuchMethodException, IllegalAccessException, InvocationTargetException {
        HashMap<String, Integer> map = new HashMap<>();
        Class<?> clazz = Class.forName("android.os.ServiceManager");
        Class<?>[] para;
        String[] Service_Name = GetService.GetServiceName(clazz);

        for (String SN : Service_Name) {
            Class<?> cla;
            int max = 0;
            bind = GetService.getIBinder(SN);
            try {
                interfaceDescribtion = bind.getInterfaceDescriptor();
                cla = Class.forName(interfaceDescribtion);
            } catch (Exception e) {
                map.put(SN, max);
                continue;
            }
            if (interfaceDescribtion == null || cla == null) {
                map.put(SN, max);
            } else {
                Method[] methods = cla.getDeclaredMethods();
                for (Method me : methods) {
                    para = me.getParameterTypes();
                    if (para.length >= max) {
                        max = para.length;
                    }
                }
                map.put(SN, max);

            }
            continue;
        }
        return map;
    }

    public static void GetTableName() throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, ClassNotFoundException {
        MaxParamap=getMaxparaNum();

        TableName tableName = new TableName(list);
        Class<?> clazz = Class.forName("android.os.ServiceManager");
        Service_Name = GetService.GetServiceName(clazz);
        for (String SN:Service_Name){
            try {
                MaxParaMax = MaxParamap.get(SN);
            }
            catch (Exception e){
                e.printStackTrace();
            }
            if(SN.contains(".")){
                SN=SN.replace(".","0");
            }
            String sql;

            String st="";
            for(int i=0;i<MaxParaMax;i++){
                st+="para"+i+" text,";
            }
            if(MaxParaMax==0){
                sql="create table "+SN+"("+"id integer primary key autoincrement,"+"interfaceCode integer,"+"InterfaceName text,"+"interfaceDescribtion text"+")";
            }
            else{
                sql="create table "+SN+"("+"id integer primary key autoincrement,"+"interfaceCode integer,"+"InterfaceName text,"+"interfaceDescribtion text,"+st.substring(0,st.length()-1)+")";
            }

            list.add(sql);
        }
        tableName.setTable(list);
    }


}
