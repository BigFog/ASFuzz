package com.zzw.asfuzzer;

import android.app.Activity;
import android.content.Intent;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;

import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.zzw.asfuzzer.FuzzUtil.Fuzz0;
import com.zzw.asfuzzer.FuzzUtil.Getlistdata;
import com.zzw.asfuzzer.ServiceUtil.GetContext;
import com.zzw.asfuzzer.ToolUtil.WhiteThread;
import com.zzw.asfuzzer.ToolUtil.whitelistDatabase;

import java.lang.reflect.InvocationTargetException;

public class FuzzActivity extends Activity {

    public String Servicename;
    private TextView show_sn;
    private TextView show_result;

    Handler handler;


    private Getlistdata getlistdata=new Getlistdata();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fuzz);

        Servicename=getIntent().getStringExtra("ServiceName");

        show_sn=findViewById(R.id.show_SN);
        show_result=findViewById(R.id.show_result);
        show_result.setMovementMethod(ScrollingMovementMethod.getInstance());
        show_sn.setText(Servicename);
        handler=new Handler(){
            @Override
            public void handleMessage(Message msg) {

                switch (msg.arg1){
                    case 0:
                        show_result.append(msg.obj.toString()+"\n");
                        break;
                    case 1:

                        show_result.append(msg.obj.toString()+"\n");
                        break;
                    case 2:

                        show_result.append(msg.obj.toString()+"\n");
                        break;
                    case 3:

                        show_result.append(msg.obj.toString()+"\n");
                        break;
                    case 4:

                        show_result.append(msg.obj.toString()+"\n");
                        break;
                }
                super.handleMessage(msg);
            }
        };


    }
    public void fuzz0(View v) throws ClassNotFoundException, NoSuchMethodException, InvocationTargetException, IllegalAccessException {

        LogUtil.e("fuzz0 测试服务名  ",Servicename);
        getlistdata.GetParafromSQL(Servicename,handler,0);      //没有参数
       // f0.setHandler(handler);
        GetContext.toastNews("fuzz0   "+Servicename);

    }
    public void fuzz1(View v) throws ClassNotFoundException, NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        getlistdata.GetParafromSQL(Servicename,handler,1);      //一个参数
        GetContext.toastNews("fuzz1  "+Servicename);
    }
    public void fuzz2(View v) throws ClassNotFoundException, NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        Log.e("test",Servicename);

        getlistdata.GetParafromSQL(Servicename,handler,2);     //两个参数
        GetContext.toastNews("fuzz2  "+Servicename);
    }
    public void fuzzmore(View v) throws ClassNotFoundException, NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        Log.e("test",Servicename);

        getlistdata.GetParafromSQL(Servicename,handler,3);     //多个参数
        GetContext.toastNews("fuzzmore   "+Servicename);

    }


}
