package com.zzw.asfuzzer.ServiceUtil;

import android.Manifest;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;


import com.zzw.asfuzzer.Database.MyIntentService;
import com.zzw.asfuzzer.ToolUtil.WhiteThread;


import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;


public class MyApplication extends Application {
    private static Context mcontext;


    public void onCreate() {

        super.onCreate();
        mcontext = getApplicationContext();

        File file=getDatabasePath("ASFuzzer.db");
        if(file.exists()){
            GetContext.toastNews(file.getAbsolutePath());
            GetContext.toastNews("数据库已创建！");
        }
        else{
            Intent intent= new Intent(this, MyIntentService.class) ;
            startService(intent);
        }
    }

    public static Context getMcontext() {
        return mcontext;
    }
    public static String getStackTraceInfo(Exception e) {

        StringWriter sw = null;
        PrintWriter pw = null;

        try {
            sw = new StringWriter();
            pw = new PrintWriter(sw);
            e.printStackTrace(pw);//将出错的栈信息输出到printWriter中
            pw.flush();
            sw.flush();

            return sw.toString();
        } catch (Exception ex) {

            return "发生错误";
        } finally {
            if (sw != null) {
                try {
                    sw.close();
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
            }
            if (pw != null) {
                pw.close();
            }
        }

    }




}
