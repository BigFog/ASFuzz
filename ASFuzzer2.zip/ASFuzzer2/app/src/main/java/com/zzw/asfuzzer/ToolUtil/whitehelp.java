package com.zzw.asfuzzer.ToolUtil;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Environment;

import com.zzw.asfuzzer.ServiceUtil.MyApplication;

import java.util.ArrayList;
import java.util.List;

public class whitehelp {
    private static SQLiteDatabase db = SQLiteDatabase.openDatabase(Environment.getExternalStorageDirectory() + "/WHITElist.db", null, SQLiteDatabase.OPEN_READWRITE);
    private static Context context = MyApplication.getMcontext();
    private static String sql;
    private static String methodStr="";
    public static String Getinvoke(String SNname) {
        List whitelist = new ArrayList();


        sql = "SELECT * FROM " + SNname;
        Cursor cursor = db.rawQuery(sql, null);
        int linenumber = cursor.getCount();  //获取表中多少行
        if (linenumber == 0) {
            return "";
        }
        if (linenumber != 0 && cursor.moveToNext()) {
            do {
                String interMethodName = cursor.getString(cursor.getColumnIndex("interMethodName"));
                whitelist.add(interMethodName);
            } while (cursor.moveToNext());

        }
        cursor.close();
        methodStr=ListToString(whitelist);
        return methodStr;
    }
    public static void WriteToWhitelist(String interMethodname,String tablename){
        whitelistDatabase dbhelper=whitelistDatabase.getdbhelper(context);
        SQLiteDatabase db=dbhelper.getWritableDatabase();
        if(!Getinvoke(tablename).contains(interMethodname)){
            ContentValues values=new ContentValues();
            values.put("interMethodName",interMethodname);
            db.insert(tablename,null,values);
            values.clear();
        }
        db.close();

    }
    public static String ListToString(List white){
        String str="";
        for(int i=0;i<white.size();i++){
            str=str+white.get(i).toString()+" ";
        }
        return str;

    }

}


