package com.zzw.asfuzzer.ServiceUtil;

import android.content.Context;
import android.widget.Toast;

public class GetContext {
    public static void toastNews(String tag){
        Context context=MyApplication.getMcontext();
        Toast.makeText(context,tag,Toast.LENGTH_SHORT).show();

    }
}
