//package com.zzw.asfuzzer.FuzzUtil;
//
//import android.content.ComponentName;
//import android.content.Intent;
//import android.net.Uri;
//import android.os.Bundle;
//import android.os.Handler;
//import android.os.IBinder;
//import android.os.Message;
//import android.os.Parcel;
//import android.os.RemoteException;
//import android.util.Log;
//
//import com.zzw.asfuzzer.LogUtil;
//import com.zzw.asfuzzer.ServiceUtil.GetService;
//import com.zzw.asfuzzer.ServiceUtil.MyApplication;
//
//import java.lang.reflect.Field;
//import java.lang.reflect.InvocationTargetException;
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.List;
//import java.util.Map;
//import java.util.Random;
//
//import static com.zzw.asfuzzer.FuzzUtil.Fuzz2Util.count;
//
//
//public class Fuzz2 implements Runnable{
//    Random rand = new Random();
//    public String Errorinfo2="";
//    private static Handler handler;
//    private int Errortime=1;
//    Fuzz2Util fuzz2=new Fuzz2Util();
//    private static int service_count2;
//    byte[] byte_para={0,1,101,-56,89,-89,-110,-1,Byte.MAX_VALUE,Byte.MIN_VALUE};
//    public long[] long_para={0,1,-1,Long.MAX_VALUE,Long.MIN_VALUE,rand.nextLong()};
//    public String[] str_para={" ","abcd","123"};
//    private int Exceptiontime=1;
//
//    private List tempValuelist=new ArrayList();
//    Getlistdata GetparaStyle=new Getlistdata();  //判断参数类型
//    public List paralist=new ArrayList();
//    public  void SetHandler(Handler handler){
//        this.handler=handler;
//
//    }
//    public Fuzz2(List paralist){
//        this.paralist.addAll(paralist);
//    }
//    /**
//     * 集合里面的数据  1，binder 2.服务名  3.接口号 4.接口方法  5.参数1 6.参数2 7.参数3
//     * 对于无参数的接口，重复调用。
//     */
//    @Override
//    public void run() {
//        Message message=handler.obtainMessage();
//        String st="接口方法-->"+paralist.get(3)+" 接口号-->"+paralist.get(2)+" 参数1-->"+paralist.get(4)+"  参数2-->"+paralist.get(5)+"\n"+"开始测试";
//        message.obj=st;
//        handler.sendMessage(message);
//        LogUtil.d("开始测试",st);
//        Fuzz2Util.makeline(); //生成执行序列
//
//        String Para1= (String) Getlistdata.GetParaStyleRelation().get(paralist.get(4));//用来判断是否为常规数据类型
//        String Para2= (String) Getlistdata.GetParaStyleRelation().get(paralist.get(5));//判断是否为常规数据类型
//        if(Para1!=null&&Para2!=null){
//                            //两个都为常规参数
//            int [] ParaStyle=GetStylePara(Para1,Para2);
//            try {
//                Class<?> clazz = Class.forName("android.os.ServiceManager");
//                service_count2=GetService.GetServiceName(clazz).length;
//                execFuzz2(ParaStyle);         //开始常规测试
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            } catch (NoSuchMethodException e) {
//                e.printStackTrace();
//            } catch (IllegalAccessException e) {
//                e.printStackTrace();
//            } catch (InvocationTargetException e) {
//                e.printStackTrace();
//            } catch (ClassNotFoundException e) {
//                e.printStackTrace();
//            }
//        }
//        else if(Para1==null&&Para2==null){ //两个参数都为对象
//            try {
//                execfuzzobj();
//            } catch (RemoteException e) {
//                e.printStackTrace();
//            } catch (ClassNotFoundException e) {
//                e.printStackTrace();
//            } catch (NoSuchMethodException e) {
//                e.printStackTrace();
//            } catch (IllegalAccessException e) {
//                e.printStackTrace();
//            } catch (InvocationTargetException e) {
//                e.printStackTrace();
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//        }
//        else{//两个之中有一个是对象实例
//            try {
//                execfuzzhalfobj(Para1,Para2);
//            } catch (RemoteException e) {
//                e.printStackTrace();
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            } catch (ClassNotFoundException e) {
//                e.printStackTrace();
//            } catch (NoSuchMethodException e) {
//                e.printStackTrace();
//            } catch (IllegalAccessException e) {
//                e.printStackTrace();
//            } catch (InvocationTargetException e) {
//                e.printStackTrace();
//            }
//
//
//        }
//    }
//    public void execfuzzhalfobj(String Para1,String Para2) throws RemoteException, InterruptedException, ClassNotFoundException, NoSuchMethodException, IllegalAccessException, InvocationTargetException {
//        String description2;
//        int intercode2;
//        List returnhalflist=new ArrayList();
//        IBinder  binder2= (IBinder) paralist.get(0);  //获取传入paralist中的binder
//        String  ServiceName2= (String) paralist.get(1); //获取传入paralist中的服务名
//        intercode2= (int) paralist.get(2);      //获取传入的接口号
//        Parcel data2 = Parcel.obtain();
//        Parcel reply2 = Parcel.obtain();
//        description2=binder2.getInterfaceDescriptor();
//        for(int i=0;i<1000;i++){
//            Thread.sleep(300);
//            if(!returnhalflist.isEmpty()) {//非空
//                if (returnhalflist.get(0).toString() == "false") {
//                    Errortime += 1;
//                }
//                String Errortext = returnhalflist.get(1).toString();
//                if (Errortext.contains("SecurityException") && (Errortext.contains("android.permission") || Errortext.contains("Neither user") || Errortext.contains("current process") || Errortext.contains("permision denied") || Errortext.contains("not allowed"))) {
//                    Exceptiontime += 1;
//                }
//                if (Errortime == 10 || Exceptiontime == 100) {
//                    Log.e("次数到了", "ceshikjhdkjshjl");
//                    Errortime = 1;
//                    Exceptiontime = 1;    //如果错误次数达到，则将time置为0.因为是全局变量。
//                    break;
//                }
//            }
//            if(!binder2.isBinderAlive()) {//每次运行前首先判断binder是否失活
//                Log.e("BINDER失活失活","BINDER DEAD!!!binder失活");
//                binder2= GetService.getIBinder(ServiceName2);
//            }
//            data2.writeInterfaceToken(description2);
//            int num;
//            List objhalf=new ArrayList();
//            if(Para1==null){   //对象，常规
//                Object [] obj=fuzz2.MultiPara((String) paralist.get(4));
//                if(obj==null){
//                    data2.writeValue(null);
//                }
//                else{
//                    data2.writeValue(obj[rand.nextInt(obj.length)]);
//                }
//                num=Integer.parseInt(Para2.split(" ")[1]);
//                data2=writedata(data2,num);
//                returnhalflist=execTransact(binder2,intercode2,data2,reply2);
//                data2.recycle();
//                reply2.recycle();
//            }
//            else{         //常规  ，对象
//                num=Integer.parseInt(Para1.split(" ")[1]);
//                data2=writedata(data2,num);
//                Object [] obj=fuzz2.MultiPara((String) paralist.get(4));
//                if(obj==null){
//                    data2.writeValue(null);
//                }
//                else{
//                    data2.writeValue(obj[rand.nextInt(obj.length)]);
//                }
//                returnhalflist=execTransact(binder2,intercode2,data2,reply2);
//                data2.recycle();
//                reply2.recycle();
//            }
//        }
//    }
//    public static  Parcel writedata(Parcel data2,int num) throws ClassNotFoundException, NoSuchMethodException, InvocationTargetException, IllegalAccessException {
//        int valueInt2;
//        int []valueIntArry2;
//        byte  valuebyte2;
//        Random rand=new Random();
//        byte[]valuebytearry2;
//        long valuelong2;
//        long[] valueLongArry2;
//        float valuefloat2;
//        float[] valueFloatArray2;
//        double valueDouble2;
//        double[] valueDoubleArray2;
//        boolean valuebool2;
//        boolean[] valueBoolArray2;
//        String valueString2;
//        String[] valueStringArray2;
//        IBinder valuebinder2;
//        Bundle valuebundle2;
//        Intent valueIntent2;
//        Intent[] valueIntentArray2;
//        List valueList2;
//        Uri valueUri2;
//        Map valueMap2;
//        ComponentName valueComponent2;
//        ComponentName[] valueComponentarray2;
//        switch (num){ //第二个选项不变
//            case 1:          //整数类型 变
//                valueInt2=Fuzz2Util.getInt();
//                LogUtil.e("测试参数 int-->",valueInt2+"");
//                data2.writeInt(valueInt2);
//                break;
//            case 2:           //intarray
//                valueIntArry2=Fuzz2Util.getIntarray(count%64);
//                data2.writeIntArray(valueIntArry2);
//                break;
//            case 3:
//                valuebyte2=DataUtil.getBytevalue(rand.nextInt(255));
//                LogUtil.e("测试参数 byte-->",valuebyte2+"");
//                data2.writeByte(valuebyte2);
//                break;
//            case 4:        //byte[]类型  变化
//                valuebytearry2=DataUtil.getbyteArry(rand.nextInt(64));
//                LogUtil.e("测试参数 byte[]-->",valuebytearry2+"");
//                data2.writeByteArray(valuebytearry2);
//                break;
//            case 5:       //long类型     变化
//                valuelong2=Fuzz2Util.getLong();
//                data2.writeLong(valuelong2);
//                Log.e("测试参数 long-->", valuelong2+"");
//                break;
//            case 6:
//                valueLongArry2=Fuzz2Util.getLongarray(count%64);
//                data2.writeLongArray(valueLongArry2);
//                break;
//            case 7:       //float 变化
//                valuefloat2=Fuzz2Util.getfloat();
//                data2.writeFloat(valuefloat2);
//                Log.e("测试参数 float-->", valuefloat2+"");
//                break;
//            case 8:
//                valueFloatArray2=Fuzz2Util.getfloatarray(count%64);
//                data2.writeFloatArray(valueFloatArray2);
//                break;
//            case 9:
//                valueDouble2=Fuzz2Util.getdouble();
//                data2.writeDouble(valueDouble2);
//                break;
//            case 10:
//                valueDoubleArray2=Fuzz2Util.getDoubleArry(count%64);
//                data2.writeDoubleArray(valueDoubleArray2);
//                break;
//            case 11:
//                valuebool2=DataUtil.getBoolean();
//                LogUtil.e("测试参数 boolean-->",valuebool2+"");
//                data2.writeValue(valuebool2);
//                break;
//            case 12:
//                valueBoolArray2=DataUtil.getbooleanArray(count%16);
//                data2.writeBooleanArray(valueBoolArray2);
//                break;
//            case 13:     //String
//                valueString2=DataUtil.getRandomString(count%30); //(i+1)%30
//                LogUtil.e("测试参数 string-->",valueString2+"");
//                data2.writeString(valueString2);
//                break;
//            case 14:
//                valueStringArray2=DataUtil.getStrArray(count%64);
//                data2.writeStringArray(valueStringArray2);
//                LogUtil.e("测试参数2 string[]-->",valueStringArray2+"");
//                break;
//            case 15:   //ibinder
//                valuebinder2= DataUtil.getbinder(rand.nextInt(service_count2)+1);
//                data2.writeStrongBinder(valuebinder2);
//                Log.e("测试参数 binder-->",valuebinder2+"");
//                break;
//            case 16:     //bundle
//                valuebundle2=DataUtil.GetBundle();   //只有一个
//                LogUtil.e("测试参数 bundle-->",valuebundle2+"");
//                data2.writeBundle(valuebundle2);
//                break;
//            case 17:          //变化的intent型
//                valueIntent2=DataUtil.GetIntent(rand.nextInt(48));
//                LogUtil.e("测试参数 intent-->",valueIntent2+"");
//                data2.writeValue(valueIntent2);
//                break;
//            case 18:     //intentarray
//                valueIntentArray2=DataUtil.getintentarry(count%32);
//                data2.writeArray(valueIntentArray2);
//                break;
//            case 19:    //list类型
//                valueList2=DataUtil.getList(rand.nextInt(30));
//                LogUtil.e("测试参数2 List-->",valueList2+"");
//                data2.writeList(valueList2);
//                break;
//            case 20:      //uri
//                valueUri2=DataUtil.GetUri(count%22);
//                LogUtil.e("测试参数1 Uri-->",valueUri2+"");
//                data2.writeValue(valueUri2);
//                break;
//            case 21://map
//                valueMap2=DataUtil.GetMap(count%21);
//                data2.writeMap(valueMap2);
//                Log.e("测试参数 map-->",valueMap2+"");
//                break;
//            case 23:
//                valueComponent2=DataUtil.getComPonentname(rand.nextInt(31));
//                data2.writeValue(valueComponent2);
//                Log.e("测试参数1 component-->",valueComponent2+"");
//                break;
//            case 24:
//                valueComponentarray2=DataUtil.getComponentArray(count%31);
//                data2.writeArray(valueComponentarray2);
//                Log.e("测试参数 component[]-->",valueComponentarray2+"");
//                break;
//        }
//        return data2;
//    }
//    public static int[] GetStylePara(String st1,String st2){//常规类型参数
//        int [] styleNum=new int[2];
//        styleNum[0]=Integer.parseInt(st1.split(" ")[1]);
//        styleNum[1]=Integer.parseInt(st2.split(" ")[1]);
//        return styleNum;  //返回值里面是两个类型所对应的的数字；
//    }
//    public void execfuzzobj() throws RemoteException, ClassNotFoundException, NoSuchMethodException, IllegalAccessException, InvocationTargetException, InterruptedException {
//        String description2;
//        int intercode2;
//        List returnlist=new ArrayList();
//        IBinder  binder2= (IBinder) paralist.get(0);  //获取传入paralist中的binder
//        String  ServiceName2= (String) paralist.get(1); //获取传入paralist中的服务名
//        intercode2= (int) paralist.get(2);      //获取传入的接口号
//        Parcel data2 = Parcel.obtain();
//        Parcel reply2 = Parcel.obtain();
//           Object[] obj1=fuzz2.MultiPara((String) paralist.get(4));
//           Object[] obj2=fuzz2.MultiPara((String) paralist.get(5));
//
//         description2=binder2.getInterfaceDescriptor();
//
//        for(int i=1;i<300;i++){
//            Thread.sleep(300);
//            if(!returnlist.isEmpty()) {//非空
//                if (returnlist.get(0).toString() == "false") {
//                    Errortime += 1;
//                }
//                String Errortext = returnlist.get(1).toString();
//                if (Errortext.contains("SecurityException") && (Errortext.contains("android.permission") || Errortext.contains("Neither user") || Errortext.contains("current process") || Errortext.contains("permision denied") || Errortext.contains("not allowed"))) {
//                    Exceptiontime += 1;
//                }
//                if (Errortime == 10 || Exceptiontime == 100) {
//                    Log.e("次数到了", "ceshikjhdkjshjl");
//                    Errortime = 1;
//                    Exceptiontime = 1;    //如果错误次数达到，则将time置为0.因为是全局变量。
//                    break;
//                }
//            }
//            if(!binder2.isBinderAlive()) {//每次运行前首先判断binder是否失活
//                Log.e("BINDER失活失活","BINDER DEAD!!!binder失活");
//                binder2= GetService.getIBinder(ServiceName2);
//            }
//            data2.writeInterfaceToken(description2);
//               if(obj1==null){
//                   data2.writeValue(null);
//               }
//               else{
//                   data2.writeValue(obj1[rand.nextInt(obj1.length)]);
//               }
//            if(obj2==null){
//                data2.writeValue(null);
//            }
//            else{
//                data2.writeValue(obj2[rand.nextInt(obj2.length)]);
//            }
//             returnlist=execTransact(binder2,intercode2,data2,reply2);
//            data2.recycle();
//            reply2.recycle();
//        }
//    }
//
//
//    public void execFuzz2(int[] ParaStylenum) throws InterruptedException, ClassNotFoundException, NoSuchMethodException, IllegalAccessException, InvocationTargetException {
//        int valueInt2;
//        int tempnum1;
//        int tempnum2;
//        Intent valueIntent2;
//        Intent[] valueIntentArray2;
//        byte valuebyte2;
//        long valuelong2;
//        int [] valueIntArry2;
//        long[] valueLongArry2;
//        byte[] valuebytearry2=null;
//        boolean  valuebool2;
//        boolean[] valueBoolArray2;
//        double valueDouble2;
//        double[] valueDoubleArray2;
//        String valueString2;
//        String[] valueStringArray2;
//        ComponentName valueComponent2;
//        ComponentName[] valueComponentarray2;
//        Uri valueUri2;
//        Map valueMap2;
//        IBinder valuebinder2;
//        Bundle valuebundle2;
//        List  valueList2;
//        float valuefloat2;
//        float [] valueFloatArray2;
//        List resultList=new ArrayList();
//
//        String description2=null;
//        int intercode2;
//        IBinder  binder2= (IBinder) paralist.get(0);  //获取传入paralist中的binder
//        String  ServiceName2= (String) paralist.get(1); //获取传入paralist中的服务名
//        intercode2= (int) paralist.get(2);      //获取传入的接口号
//        Parcel data2 = Parcel.obtain();
//        Parcel reply2 = Parcel.obtain();
//        try {
//            description2=binder2.getInterfaceDescriptor();
//        } catch (RemoteException e) {
//            Log.e("error","接口描述符错误");
//            e.printStackTrace();
//        }
//        for(int count=1;count<1501;count++){
//            Thread.sleep(300);
//            Log.e("当前日志","接口名---->"+paralist.get(3)+"  "+"接口号---->"+paralist.get(2)+" 参数1-->"+paralist.get(4)+"  参数2-->"+paralist.get(5));
//            if(!binder2.isBinderAlive()) {//每次运行前首先判断binder是否失活
//                Log.e("BINDER失活失活","BINDER DEAD!!!binder失活");
//                binder2= GetService.getIBinder(ServiceName2);
//            }
//            data2.writeInterfaceToken(description2);
//            if(count<501){
//                if(!resultList.isEmpty()){//非空
//                    if(resultList.get(0).toString()=="false"){
//                        Errortime+=1;
//                    }
//                    String Errortext=resultList.get(1).toString();
//                    if(Errortext.contains("SecurityException")&&(Errortext.contains("android.permission")||Errortext.contains("Neither user")||Errortext.contains("current process")||Errortext.contains("permision denied")||Errortext.contains("not allowed"))){
//                        Exceptiontime+=1;
//                    }
//                    if(Errortime==10||Exceptiontime==100){
//                        Log.e("次数到了","ceshikjhdkjshjl");
//                        Errortime=1;
//                        Exceptiontime=1;    //如果错误次数达到，则将time置为0.因为是全局变量。
//                        break;
//                    }
//                }
//                tempnum1=ParaStylenum[0];
//                tempnum2=ParaStylenum[1];
//                switch (tempnum1){ //第一个选项不变
//                    case 1:     //int 不变
//                        if(tempValuelist.isEmpty()){
//                            valueInt2=1;
//                            tempValuelist.add(valueInt2);
//                        }
//                        valueInt2=(int)tempValuelist.get(0);
//                        LogUtil.e("测试参数1 int-->",valueInt2+"");
//                        data2.writeInt(valueInt2);
//                        break;
//                    case 2:
//                        if(tempValuelist.isEmpty()){
//                            valueIntArry2=new int[]{1,-1,Integer.MAX_VALUE,Integer.MIN_VALUE};
//                            tempValuelist.add(valueIntArry2);
//                        }
//                        valueIntArry2= (int[]) tempValuelist.get(0);
//                        data2.writeIntArray(valueIntArry2);
//                        break;
//                    case 3:      //byte
//                        if(tempValuelist.isEmpty()){
//                            valuebyte2=1;
//                            tempValuelist.add(valuebyte2);
//                        }
//                        valuebyte2=(byte)tempValuelist.get(0);
//                        LogUtil.e("测试参数1 byte-->",valuebyte2+"");
//                        data2.writeByte(valuebyte2);
//                        break;
//                    case 4:   //byte[]类型   不变
//                        if(tempValuelist.isEmpty()){
//                            valuebytearry2=byte_para;
//                            tempValuelist.add(valuebytearry2);
//                        }
//                        valuebytearry2=(byte[])tempValuelist.get(0);
//                        LogUtil.e("测试参数1 byte[]-->",Arrays.toString(valuebytearry2)+"");
//                        data2.writeByteArray(valuebytearry2);
//                        break;
//                    case 5:  //long
//                        if(tempValuelist.isEmpty()){
//                            valuelong2=1l;
//                            tempValuelist.add(valuelong2);
//                        }
//                        valuelong2= (long) tempValuelist.get(0);
//                        data2.writeLong(valuelong2);
//                        LogUtil.e("测试参数1 long-->",valuelong2+"");
//                        break;
//                    case 6:
//                        if(tempValuelist.isEmpty()){
//                            valueLongArry2=new long[]{0,1,-1,Long.MIN_VALUE,Long.MIN_VALUE};
//                            tempValuelist.add(valueLongArry2);
//                        }
//                        valueLongArry2= (long[]) tempValuelist.get(0);
//                        data2.writeLongArray(valueLongArry2);
//                        break;
//                    case 7:       //float 不变
//                        if(tempValuelist.isEmpty()){
//                            valuefloat2=1f;
//                            tempValuelist.add(valuefloat2);
//                        }
//                        valuefloat2= (float) tempValuelist.get(0);
//                        data2.writeFloat(valuefloat2);
//                        Log.e("测试参数 float-->", valuefloat2+"");
//                        break;
//                    case 8:
//                        if(tempValuelist.isEmpty()){
//                            valueFloatArray2=new float[]{0,1,-1,Long.MIN_VALUE,Long.MAX_VALUE};
//                            tempValuelist.add(valueFloatArray2);
//                        }
//                        valueFloatArray2= (float[]) tempValuelist.get(0);
//                        data2.writeFloatArray(valueFloatArray2);
//                        Log.e("测试参数 float-->", valueFloatArray2+"");
//                        break;
//                    case 9:
//                        if(tempValuelist.isEmpty()){
//                            valueDouble2=1;
//                            tempValuelist.add(valueDouble2);
//                        }
//                        valueDouble2= (double) tempValuelist.get(0);
//                        data2.writeDouble(valueDouble2);
//                        break;
//                    case 10:
//                        if(tempValuelist.isEmpty()){
//                            valueDoubleArray2=new double[]{0,1,-1,};
//                            tempValuelist.add(valueDoubleArray2);
//                        }
//                        valueDoubleArray2= (double[]) tempValuelist.get(0);
//                        data2.writeDoubleArray(valueDoubleArray2);
//                        break;
//
//                    case 11:     //boolean 类型
//                        valuebool2=DataUtil.getBoolean();   //只有两个特殊
//                        LogUtil.e("测试参数2 boolean-->",valuebool2+"");
//                        data2.writeValue(valuebool2);
//                        break;
//                    case 12:
//                        if(tempValuelist.isEmpty()){
//                            valueBoolArray2=new boolean[]{true,false};
//                            tempValuelist.add(valueBoolArray2);
//                        }
//                        valueBoolArray2= (boolean[]) tempValuelist.get(0);
//                        data2.writeBooleanArray(valueBoolArray2);
//                        break;
//                    case 13:   //String 字符串类型 不变
//                        if(tempValuelist.isEmpty()){
//                            valueString2=DataUtil.getRandomString(6); //(i+1)%30
//                            tempValuelist.add(valueString2);
//                        }
//                        valueString2=tempValuelist.get(0).toString();
//                        LogUtil.e("测试参数1 string-->",valueString2+"");
//                        data2.writeString(valueString2);
//                        break;
//                    case 14:
//                        valueStringArray2=str_para;
//                        data2.writeStringArray(valueStringArray2);
//                        LogUtil.e("测试参数2 string[]-->",valueStringArray2+"");
//                        break;
//                    case 15:   //ibinder
//                        if(tempValuelist.isEmpty()){
//                            valuebinder2=DataUtil.getbinder(1);
//                            tempValuelist.add(valuebinder2);
//                        }
//                        valuebinder2= (IBinder) tempValuelist.get(0);
//                        data2.writeStrongBinder(valuebinder2);
//                        break;
//                    case 16:     //bundle
//                        valuebundle2=DataUtil.GetBundle();   //只有一个
//                        LogUtil.e("测试参数 bundle-->",valuebundle2+"");
//                        data2.writeBundle(valuebundle2);
//                        break;
//                    case 17: //intent类型不变
//                        if(tempValuelist.isEmpty()){
//                            valueIntent2=DataUtil.GetIntent(rand.nextInt(48)+1);
//                            tempValuelist.add(valueIntent2);
//                        }
//                        valueIntent2=(Intent)tempValuelist.get(0);
//                        LogUtil.e("测试参数1 intent-->",valueIntent2+"");
//                        data2.writeValue(valueIntent2);
//                        break;
//                    case 18:
//                        if(tempValuelist.isEmpty()){
//                            valueIntentArray2=DataUtil.getintentarry(1);
//                            tempValuelist.add(valueIntentArray2);
//                        }
//                        valueIntentArray2= (Intent[]) tempValuelist.get(0);
//                        data2.writeArray(valueIntentArray2);
//                        break;
//
//                    case 19: //list
//                        if(tempValuelist.isEmpty()){
//                            valueList2=DataUtil.getList(3);
//                            tempValuelist.add(valueList2);
//                        }
//                        valueList2= (List) tempValuelist.get(0);
//                        data2.writeList(valueList2);
//                        LogUtil.e("测试参数1 list-->",valueList2+"");
//                        break;
//                    case 20:   //uri
//                        if(tempValuelist.isEmpty()){
//                            valueUri2=DataUtil.GetUri(1);
//                            tempValuelist.add(valueUri2);
//                        }
//                        valueUri2= (Uri) tempValuelist.get(0);
//                        data2.writeValue(valueUri2);
//                        LogUtil.e("测试参数1 Uri-->",valueUri2+"");
//                        break;
//                    case 21:
//                        if(tempValuelist.isEmpty()){
//                            valueMap2=DataUtil.GetMap(1);
//                            tempValuelist.add(valueMap2);
//                        }
//                        valueMap2= (Map) tempValuelist.get(0);
//                        data2.writeMap(valueMap2);
//                        break;
//                    case 23:  //component
//                        if(tempValuelist.isEmpty()){
//                            valueComponent2=DataUtil.getComPonentname(3);
//                            tempValuelist.add(valueComponent2);
//                        }
//                        valueComponent2= (ComponentName) tempValuelist.get(0);
//                        data2.writeValue(valueComponent2);
//                        LogUtil.e("测试参数1 component-->",valueComponent2+"");
//                        break;
//                    case 24:
//                        if(tempValuelist.isEmpty()){
//                            valueComponentarray2=DataUtil.getComponentArray(3);
//                            tempValuelist.add(valueComponentarray2);
//                        }
//                        valueComponentarray2= (ComponentName[]) tempValuelist.get(0);
//                        data2.writeArray(valueComponentarray2);
//                        break;
//                    }
//                switch(tempnum2){   //第二个要变化的字符串
//
//                    case 1:          //整数类型 变int型
//                        valueInt2=Fuzz1Util.getInt();
//                        LogUtil.e("测试参数2 int-->",valueInt2+"");
//                        data2.writeInt(valueInt2);
//                        break;
//                    case 2:           //intarray
//                        valueIntArry2=Fuzz2Util.getIntarray(count%64);
//                        data2.writeIntArray(valueIntArry2);
//                        break;
//                    case 3:    //byte类型
//                        valuebyte2=DataUtil.getBytevalue(count%255);
//                        LogUtil.e("测试参数2 byte-->",valuebyte2+"");
//                        data2.writeByte(valuebyte2);
//                        break;
//                    case 4:        //byte[]类型  变化
//                        valuebytearry2=DataUtil.getbyteArry(count%64);
//                        LogUtil.e("测试参数2 byte[]-->",valuebytearry2+"");
//                        data2.writeByteArray(valuebytearry2);
//                        break;
//                    case 5:       //long类型     变化
//                        valuelong2=Fuzz2Util.getLong();
//                        data2.writeLong(valuelong2);
//                        Log.e("测试参数 long-->", valuelong2+"");
//                        break;
//                    case 6:
//                        valueLongArry2=Fuzz2Util.getLongarray(count%64);
//                        data2.writeLongArray(valueLongArry2);
//                        break;
//                    case 7:       //float 变化
//                        valuefloat2=Fuzz2Util.getfloat();
//                        data2.writeFloat(valuefloat2);
//                        Log.e("测试参数 float-->", valuefloat2+"");
//                        break;
//                    case 8:
//                        valueFloatArray2=Fuzz2Util.getfloatarray(count%64);
//                        data2.writeFloatArray(valueFloatArray2);
//                        break;
//                    case 9:
//                        valueDouble2=Fuzz2Util.getdouble();
//                        data2.writeDouble(valueDouble2);
//                        break;
//                    case 10:
//                        valueDoubleArray2=Fuzz2Util.getDoubleArry(count%64);
//                        data2.writeDoubleArray(valueDoubleArray2);
//                        break;
//                    case 11:     //boolean 类型
//                        valuebool2=DataUtil.getBoolean();
//                        LogUtil.e("测试参数2 boolean-->",valuebool2+"");
//                        data2.writeValue(valuebool2);
//                        break;
//                    case 12:
//                        valueBoolArray2=DataUtil.getbooleanArray(count%16);
//                        data2.writeBooleanArray(valueBoolArray2);
//                        break;
//                    case 13:        //字符串类型 变string型
//                        valueString2=DataUtil.getRandomString(count%30); //(i+1)%30
//                        LogUtil.e("测试参数2 string-->",valueString2+"");
//                        data2.writeString(valueString2);
//                        break;
//                    case 14:
//                        valueStringArray2=DataUtil.getStrArray(count%64);
//                        data2.writeStringArray(valueStringArray2);
//                        LogUtil.e("测试参数2 string[]-->",valueStringArray2+"");
//                        break;
//                    case 15:   //ibinder
//                        valuebinder2= DataUtil.getbinder(rand.nextInt(service_count2)+1);
//                        data2.writeStrongBinder(valuebinder2);
//                        Log.e("测试参数 binder-->",valuebinder2+"");
//                        break;
//                    case 16:     //bundle
//                        valuebundle2=DataUtil.GetBundle();
//                        LogUtil.e("测试参数2 bundle-->",valuebundle2+"");
//                        data2.writeBundle(valuebundle2);
//                        break;
//                    case 17:          //变化的intent型
//                        valueIntent2=DataUtil.GetIntent(count%48);
//                        LogUtil.e("测试参数2 intent-->",valueIntent2+"");
//                        data2.writeValue(valueIntent2);
//                        break;
//                    case 18:
//                        valueIntentArray2=DataUtil.getintentarry(count%32);
//                        data2.writeArray(valueIntentArray2);
//                        break;
//                    case 19:    //list类型
//                        valueList2=DataUtil.getList(count%30);
//                        LogUtil.e("测试参数2 List-->",valueList2+"");
//                        data2.writeList(valueList2);
//                        break;
//                    case 20:      //uri
//                        valueUri2=DataUtil.GetUri(count%22);
//                        LogUtil.e("测试参数1 Uri-->",valueUri2+"");
//                        data2.writeValue(valueUri2);
//                        break;
//                    case 21://map
//                        valueMap2=DataUtil.GetMap(count%21);
//                        data2.writeMap(valueMap2);
//                        Log.e("测试参数 map-->",valueMap2+"");
//                        break;
//
//                    case 23:
//                        valueComponent2=DataUtil.getComPonentname(rand.nextInt(31));
//                        data2.writeValue(valueComponent2);
//                        Log.e("测试参数1 component-->",valueComponent2+"");
//                        break;
//                    case 24:
//                        valueComponentarray2=DataUtil.getComponentArray(count%31);
//                        data2.writeArray(valueComponentarray2);
//                        Log.e("测试参数 component[]-->",valueComponentarray2+"");
//                        break;
//                    }
//                resultList=execTransact(binder2,intercode2,data2,reply2);
//                data2.recycle();
//                reply2.recycle();
//                }
//            //当前500运行完，则运行下一步
//            if(count==501){
//                Errortime=1;
//                Exceptiontime=1;
//                tempValuelist.clear();    //保存不变值的list
//                resultList.clear();    //执行结果保存数组，第一个是执行结果，第二个是异常。
//            }
//            if(501<count&&count<1000){
//                if(!resultList.isEmpty()){//非空
//                    if(resultList.get(0).toString()=="false"){
//                        Errortime+=1;
//                    }
//                    String Errortext=resultList.get(1).toString();
//                    if(Errortext.contains("SecurityException")&&(Errortext.contains("android.permission")||Errortext.contains("Neither user")||Errortext.contains("current process")||Errortext.contains("permision denied")||Errortext.contains("not allowed"))){
//                        Exceptiontime+=1;
//                    }
//                    if(Errortime==10||Exceptiontime==100){
//                        Log.e("次数到了","ceshikjhdkjshjl");
//                        Errortime=1;
//                        Exceptiontime=1;    //如果错误次数达到，则将time置为0.因为是全局变量。
//                        break;
//                    }
//                }
//                tempnum1=ParaStylenum[0];
//                tempnum2=ParaStylenum[1];
//                switch(tempnum1){ //变化的
//                    case 1:          //整数类型 变int型
//                        valueInt2=Fuzz1Util.getInt();
//                        LogUtil.e("测试参数1 int-->",valueInt2+"");
//                        data2.writeInt(valueInt2);
//                        break;
//                    case 2:           //intarray
//                        valueIntArry2=Fuzz2Util.getIntarray(count%64);
//                        data2.writeIntArray(valueIntArry2);
//                        break;
//                    case 3:
//                        valuebyte2=DataUtil.getBytevalue(rand.nextInt(255));
//                        LogUtil.e("测试参数 byte-->",valuebyte2+"");
//                        data2.writeByte(valuebyte2);
//                        break;
//                    case 4:        //byte[]类型  变化
//                        valuebytearry2=DataUtil.getbyteArry(count%64);
//                        LogUtil.e("测试参数1 byte[]-->",valuebytearry2+"");
//                        data2.writeByteArray(valuebytearry2);
//                        break;
//                    case 5:       //long类型     变化
//                        valuelong2=Fuzz2Util.getLong();
//                        data2.writeLong(valuelong2);
//                        Log.e("测试参数 long-->", valuelong2+"");
//                        break;
//                    case 6:
//                        valueLongArry2=Fuzz2Util.getLongarray(count%64);
//                        data2.writeLongArray(valueLongArry2);
//                        break;
//                    case 7:       //float 变化
//                        valuefloat2=Fuzz2Util.getfloat();
//                        data2.writeFloat(valuefloat2);
//                        Log.e("测试参数 float-->", valuefloat2+"");
//                        break;
//                    case 8:
//                        valueFloatArray2=Fuzz2Util.getfloatarray(count%64);
//                        data2.writeFloatArray(valueFloatArray2);
//                        break;
//                    case 9:
//                        valueDouble2=Fuzz2Util.getdouble();
//                        data2.writeDouble(valueDouble2);
//                        break;
//                    case 10:
//                        valueDoubleArray2=Fuzz2Util.getDoubleArry(count%64);
//                        data2.writeDoubleArray(valueDoubleArray2);
//                        break;
//                    case 11:     //boolean 类型
//                        valuebool2=DataUtil.getBoolean();
//                        LogUtil.e("测试参数2 boolean-->",valuebool2+"");
//                        data2.writeValue(valuebool2);
//                        break;
//                    case 12:
//                        valueBoolArray2=DataUtil.getbooleanArray(count%16);
//                        data2.writeBooleanArray(valueBoolArray2);
//                        break;
//                    case 13:         //变化的字符串型
//                        valueString2=DataUtil.getRandomString(count%30); //(i+1)%30
//                        LogUtil.e("测试参数1 string-->",valueString2+"");
//                        data2.writeString(valueString2);
//                        break;
//                    case 14:
//                        valueStringArray2=DataUtil.getStrArray(count%64);
//                        data2.writeStringArray(valueStringArray2);
//                        LogUtil.e("测试参数2 string[]-->",valueStringArray2+"");
//                        break;
//                    case 15:
//                        valuebinder2= DataUtil.getbinder(count%service_count2+1);
//                        data2.writeStrongBinder(valuebinder2);
//                        Log.e("测试参数 binder-->",valuebinder2+"");
//                        break;
//                    case 16:     //bundle
//                        valuebundle2=DataUtil.GetBundle();   //只有一个
//                        LogUtil.e("测试参数2 bundle-->",valuebundle2+"");
//                        data2.writeBundle(valuebundle2);
//                        break;
//                    case 17:          //变化的intent型
//                        valueIntent2=DataUtil.GetIntent(count%48);
//                        LogUtil.e("测试参数1 intent-->",valueIntent2+"");
//                        data2.writeValue(valueIntent2);
//                        break;
//                    case 18:
//                        valueIntentArray2=DataUtil.getintentarry(count%32);
//                        data2.writeArray(valueIntentArray2);
//                        break;
//                    case 19:    //list类型
//                        valueList2=DataUtil.getList(count%30);
//                        LogUtil.e("测试参数1 List-->",valueList2+"");
//                        data2.writeList(valueList2);
//                        break;
//                    case 20:      //uri
//                        valueUri2=DataUtil.GetUri(count%22);
//                        LogUtil.e("测试参数1 Uri-->",valueUri2+"");
//                        data2.writeValue(valueUri2);
//                        break;
//                    case 21://map
//                        valueMap2=DataUtil.GetMap(count%21);
//                        data2.writeMap(valueMap2);
//                        Log.e("测试参数 map-->",valueMap2+"");
//                        break;
//
//                    case 23:
//                        valueComponent2=DataUtil.getComPonentname(count%31);
//                        data2.writeValue(valueComponent2);
//                        Log.e("测试参数1 component-->",valueComponent2+"");
//                        break;
//                    case 24:
//                        valueComponentarray2=DataUtil.getComponentArray(count%31);
//                        data2.writeArray(valueComponentarray2);
//                        Log.e("测试参数 component[]-->",valueComponentarray2+"");
//                        break;
//                }
//                switch (tempnum2){ //第二个选项不变
//                    case 1:          //不变的整数型
//                        if(tempValuelist.isEmpty()){
//                            valueInt2=1;
//                            tempValuelist.add(valueInt2);
//                        }
//                        valueInt2=(int)tempValuelist.get(0);
//                        LogUtil.e("测试参数2 int-->",valueInt2+"");
//                        data2.writeInt(valueInt2);
//                        break;
//                    case 2:
//                        if(tempValuelist.isEmpty()){
//                            valueIntArry2=new int[]{1,-1,Integer.MAX_VALUE,Integer.MIN_VALUE};
//                            tempValuelist.add(valueIntArry2);
//                        }
//                        valueIntArry2= (int[]) tempValuelist.get(0);
//                        data2.writeIntArray(valueIntArry2);
//                        break;
//                    case 3:      //byte
//                        if(tempValuelist.isEmpty()){
//                            valuebyte2=1;
//                            tempValuelist.add(valuebyte2);
//                        }
//                        valuebyte2=(byte)tempValuelist.get(0);
//                        LogUtil.e("测试参数1 byte-->",valuebyte2+"");
//                        data2.writeByte(valuebyte2);
//                        break;
//                    case 4:   //byte[]类型   不变
//                        if(tempValuelist.isEmpty()){
//                            valuebytearry2=byte_para;
//                            tempValuelist.add(valuebytearry2);
//                        }
//                        valuebytearry2=(byte[])tempValuelist.get(0);
//                        LogUtil.e("测试参数1 byte[]-->",Arrays.toString(valuebytearry2)+"");
//                        data2.writeByteArray(valuebytearry2);
//                        break;
//                    case 5:   //long  类型  不变
//                        if(tempValuelist.isEmpty()){
//                            valuelong2=2l;
//                            tempValuelist.add(valuelong2);
//                        }
//                        valuelong2= (long) tempValuelist.get(0);
//                        data2.writeLong(valuelong2);
//                        LogUtil.e("测试参数 long-->", valuelong2+"");
//                        break;
//                    case 6:
//                        if(tempValuelist.isEmpty()){
//                            valueLongArry2=new long[]{0,1,-1,Long.MIN_VALUE,Long.MIN_VALUE};
//                            tempValuelist.add(valueLongArry2);
//                        }
//                        valueLongArry2= (long[]) tempValuelist.get(0);
//                        data2.writeLongArray(valueLongArry2);
//                        break;
//                    case 7:       //float 不变
//                        if(tempValuelist.isEmpty()){
//                            valuefloat2=1f;
//                            tempValuelist.add(valuefloat2);
//                        }
//                        valuefloat2= (float) tempValuelist.get(0);
//                        data2.writeFloat(valuefloat2);
//                        Log.e("测试参数 float-->", valuefloat2+"");
//                        break;
//                    case 8:
//                        if(tempValuelist.isEmpty()){
//                            valueFloatArray2=new float[]{0,1,-1,Long.MIN_VALUE,Long.MAX_VALUE};
//                            tempValuelist.add(valueFloatArray2);
//                        }
//                        valueFloatArray2= (float[]) tempValuelist.get(0);
//                        data2.writeFloatArray(valueFloatArray2);
//                        Log.e("测试参数 float-->", valueFloatArray2+"");
//                        break;
//                    case 9:
//                        if(tempValuelist.isEmpty()){
//                          valueDouble2=1;
//                          tempValuelist.add(valueDouble2);
//                        }
//                        valueDouble2= (double) tempValuelist.get(0);
//                        data2.writeDouble(valueDouble2);
//                        break;
//                    case 10:
//                        if(tempValuelist.isEmpty()){
//                            valueDoubleArray2=new double[]{0,1,-1,};
//                            tempValuelist.add(valueDoubleArray2);
//                        }
//                        valueDoubleArray2= (double[]) tempValuelist.get(0);
//                        data2.writeDoubleArray(valueDoubleArray2);
//                        break;
//                    case 11:   //特殊就两个值
//                        valuebool2=DataUtil.getBoolean();
//                        LogUtil.e("测试参数2 boolean-->",valuebool2+"");
//                        data2.writeValue(valuebool2);
//                        break;
//                    case 12:
//                        if(tempValuelist.isEmpty()){
//                            valueBoolArray2=new boolean[]{true,false};
//                            tempValuelist.add(valueBoolArray2);
//                        }
//                        valueBoolArray2= (boolean[]) tempValuelist.get(0);
//                        data2.writeBooleanArray(valueBoolArray2);
//                        break;
//                    case 13:     //string 不变
//                        if(tempValuelist.isEmpty()){
//                            valueString2=DataUtil.getRandomString(6); //(i+1)%30
//                            tempValuelist.add(valueString2);
//                        }
//                        valueString2=tempValuelist.get(0).toString();
//                        LogUtil.e("测试参数2 string-->",valueString2+"");
//                        data2.writeString(valueString2);
//                        break;
//                    case 14:
//                        valueStringArray2=str_para;
//                        data2.writeStringArray(valueStringArray2);
//                        LogUtil.e("测试参数2 string[]-->",valueStringArray2+"");
//                        break;
//                    case 15:
//                        if(tempValuelist.isEmpty()){
//                            valuebinder2=DataUtil.getbinder(count%10);
//                            tempValuelist.add(valuebinder2);
//                        }
//                        valuebinder2= (IBinder) tempValuelist.get(0);
//                        data2.writeStrongBinder(valuebinder2);
//                        break;
//                    case 16:     //bundle
//                        valuebundle2=DataUtil.GetBundle();   //只有一个
//                        LogUtil.e("测试参数2 bundle-->",valuebundle2+"");
//                        data2.writeBundle(valuebundle2);
//                        break;
//                    case 17: //intent类型不变
//                        if(tempValuelist.isEmpty()){
//                            valueIntent2=DataUtil.GetIntent(rand.nextInt(48)+1);
//                            tempValuelist.add(valueIntent2);
//                        }
//                        valueIntent2=(Intent)tempValuelist.get(0);
//                        LogUtil.e("测试参数1 intent-->",valueIntent2+"");
//                        data2.writeValue(valueIntent2);
//                        break;
//                    case 18:
//                        if(tempValuelist.isEmpty()){
//                            valueIntentArray2=DataUtil.getintentarry(1);
//                            tempValuelist.add(valueIntentArray2);
//                        }
//                        valueIntentArray2= (Intent[]) tempValuelist.get(0);
//                        data2.writeArray(valueIntentArray2);
//                        break;
//
//                    case 19: //list
//                        if(tempValuelist.isEmpty()){
//                            valueList2=DataUtil.getList(3);
//                            tempValuelist.add(valueList2);
//                        }
//                        valueList2= (List) tempValuelist.get(0);
//                        data2.writeList(valueList2);
//                        break;
//                    case 20:
//                        if(tempValuelist.isEmpty()){
//                            valueUri2=DataUtil.GetUri(1);
//                            tempValuelist.add(valueUri2);
//                        }
//                        valueUri2= (Uri) tempValuelist.get(0);
//                        data2.writeValue(valueUri2);
//                        break;
//                    case 21:
//                        valueMap2=DataUtil.GetMap(1);
//                        data2.writeMap(valueMap2);
//                        break;
//
//                    case 23:  //component
//                        if(tempValuelist.isEmpty()){
//                            valueComponent2=DataUtil.getComPonentname(3);
//                            tempValuelist.add(valueComponent2);
//                        }
//                        valueComponent2= (ComponentName) tempValuelist.get(0);
//                        data2.writeValue(valueComponent2);
//                        LogUtil.e("测试参数 component-->",valueComponent2+"");
//                        break;
//                    case 24:
//                        if(tempValuelist.isEmpty()){
//                            valueComponentarray2=DataUtil.getComponentArray(3);
//                            tempValuelist.add(valueComponentarray2);
//                        }
//                        valueComponentarray2= (ComponentName[]) tempValuelist.get(0);
//                        data2.writeArray(valueComponentarray2);
//                        break;
//                }
//                resultList=execTransact(binder2,intercode2,data2,reply2);
//                data2.recycle();
//                reply2.recycle();
//            }
//            //当前500运行完，则运行下一步
//            if(count==1001){
//                Errortime=1;
//                Exceptiontime=1;
//                tempValuelist.clear();    //保存不变值的list
//                resultList.clear();    //执行结果保存数组，第一个是执行结果，第二个是异常。
//            }
//
//            if(1001<count&&count<1501){
//                if(!resultList.isEmpty()){//非空
//                    if(resultList.get(0).toString()=="false"){
//                        Errortime+=1;
//                    }
//                    String Errortext=resultList.get(1).toString();
//                    if(Errortext.contains("SecurityException")&&(Errortext.contains("android.permission")||Errortext.contains("Neither user")||Errortext.contains("current process")||Errortext.contains("permision denied")||Errortext.contains("not allowed"))){
//                        Exceptiontime+=1;
//                    }
//                    if(Errortime==10||Exceptiontime==100){
//                        Log.e("次数到了","换新方法，新接口！");
//                        Errortime=1;
//                        Exceptiontime=1;    //如果错误次数达到，则将time置为0.因为是全局变量。
//                        break;
//                    }
//                }
//                for(int i=0;i<2;i++){
//                    switch (ParaStylenum[i]){ //第二个选项不变
//                        case 1:          //整数类型 变
//                            valueInt2=Fuzz2Util.getInt();
//                            LogUtil.e("测试参数 int-->",valueInt2+"");
//                            data2.writeInt(valueInt2);
//                            break;
//                        case 2:           //intarray
//                            valueIntArry2=Fuzz2Util.getIntarray(count%64);
//                            data2.writeIntArray(valueIntArry2);
//                            break;
//                        case 3:
//                            valuebyte2=DataUtil.getBytevalue(rand.nextInt(255));
//                            LogUtil.e("测试参数 byte-->",valuebyte2+"");
//                            data2.writeByte(valuebyte2);
//                            break;
//                        case 4:        //byte[]类型  变化
//                            valuebytearry2=DataUtil.getbyteArry(rand.nextInt(64));
//                            LogUtil.e("测试参数 byte[]-->",valuebytearry2+"");
//                            data2.writeByteArray(valuebytearry2);
//                            break;
//                        case 5:       //long类型     变化
//                            valuelong2=Fuzz2Util.getLong();
//                            data2.writeLong(valuelong2);
//                            Log.e("测试参数 long-->", valuelong2+"");
//                            break;
//                        case 6:
//                            valueLongArry2=Fuzz2Util.getLongarray(count%64);
//                            data2.writeLongArray(valueLongArry2);
//                            break;
//                        case 7:       //float 变化
//                            valuefloat2=Fuzz2Util.getfloat();
//                            data2.writeFloat(valuefloat2);
//                            Log.e("测试参数 float-->", valuefloat2+"");
//                            break;
//                        case 8:
//                            valueFloatArray2=Fuzz2Util.getfloatarray(count%64);
//                            data2.writeFloatArray(valueFloatArray2);
//                            break;
//                        case 9:
//                            valueDouble2=Fuzz2Util.getdouble();
//                            data2.writeDouble(valueDouble2);
//                            break;
//                        case 10:
//                            valueDoubleArray2=Fuzz2Util.getDoubleArry(count%64);
//                            data2.writeDoubleArray(valueDoubleArray2);
//                            break;
//                        case 11:
//                            valuebool2=DataUtil.getBoolean();
//                            LogUtil.e("测试参数 boolean-->",valuebool2+"");
//                            data2.writeValue(valuebool2);
//                            break;
//                        case 12:
//                            valueBoolArray2=DataUtil.getbooleanArray(count%16);
//                            data2.writeBooleanArray(valueBoolArray2);
//                            break;
//                        case 13:     //String
//                            valueString2=DataUtil.getRandomString(count%30); //(i+1)%30
//                            LogUtil.e("测试参数 string-->",valueString2+"");
//                            data2.writeString(valueString2);
//                            break;
//                        case 14:
//                            valueStringArray2=DataUtil.getStrArray(count%64);
//                            data2.writeStringArray(valueStringArray2);
//                            LogUtil.e("测试参数2 string[]-->",valueStringArray2+"");
//                            break;
//                        case 15:   //ibinder
//                            valuebinder2= DataUtil.getbinder(rand.nextInt(service_count2)+1);
//                            data2.writeStrongBinder(valuebinder2);
//                            Log.e("测试参数 binder-->",valuebinder2+"");
//                            break;
//                        case 16:     //bundle
//                            valuebundle2=DataUtil.GetBundle();   //只有一个
//                            LogUtil.e("测试参数 bundle-->",valuebundle2+"");
//                            data2.writeBundle(valuebundle2);
//                            break;
//                        case 17:          //变化的intent型
//                            valueIntent2=DataUtil.GetIntent(rand.nextInt(48));
//                            LogUtil.e("测试参数 intent-->",valueIntent2+"");
//                            data2.writeValue(valueIntent2);
//                            break;
//                        case 18:
//                            valueIntentArray2=DataUtil.getintentarry(count%32);
//                            data2.writeArray(valueIntentArray2);
//                            break;
//                        case 19:    //list类型
//                            valueList2=DataUtil.getList(rand.nextInt(30));
//                            LogUtil.e("测试参数2 List-->",valueList2+"");
//                            data2.writeList(valueList2);
//                            break;
//                        case 20:      //uri
//                            valueUri2=DataUtil.GetUri(count%22);
//                            LogUtil.e("测试参数1 Uri-->",valueUri2+"");
//                            data2.writeValue(valueUri2);
//                            break;
//                        case 21://map
//                            valueMap2=DataUtil.GetMap(count%21);
//                            data2.writeMap(valueMap2);
//                            Log.e("测试参数 map-->",valueMap2+"");
//                            break;
//
//                        case 23:
//                            valueComponent2=DataUtil.getComPonentname(rand.nextInt(31));
//                            data2.writeValue(valueComponent2);
//                            Log.e("测试参数1 component-->",valueComponent2+"");
//                            break;
//                        case 24:
//                            valueComponentarray2=DataUtil.getComponentArray(count%31);
//                            data2.writeArray(valueComponentarray2);
//                            Log.e("测试参数 component[]-->",valueComponentarray2+"");
//                            break;
//
//                    }
//                }
//                resultList=execTransact(binder2,intercode2,data2,reply2);
//                data2.recycle();
//                reply2.recycle();
//
//            }
//            if(count==1500){
//                Errortime=1;
//                Exceptiontime=1;
//                tempValuelist.clear();    //保存不变值的list
//                resultList.clear();    //执行结果保存数组，第一个是执行结果，第二个是异常。
//            }
//        }
//    }
//    public List execTransact(IBinder binder2,int intercode,Parcel data2,Parcel replay2){
//        boolean resultcode=true;
//        List list=new ArrayList();
//        try {
//
//           resultcode=binder2.transact(intercode,data2,replay2,0);
//           list.add(resultcode);
//           replay2.readException();
//        } catch (Exception e) {
//            Errorinfo2= MyApplication.getStackTraceInfo(e);
//            list.add(Errorinfo2);
//            LogUtil.e("打印异常","@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@开始打印异常@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
//            LogUtil.e("异常信息",Errorinfo2);
//            LogUtil.e("打印异常","@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@打印异常结束@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
//            LogUtil.e("ERROR","服务名 "+paralist.get(1)+"接口名-->"+paralist.get(3)+"  "+"接口号-->"+paralist.get(2)+" 参数1-->"+paralist.get(4)+" 参数2-->"+paralist.get(5));
//            e.printStackTrace();
//        }
//        finally {
//            data2.recycle();
//            replay2.recycle();
//        }
//        return list;
//    }
//
//
//}
