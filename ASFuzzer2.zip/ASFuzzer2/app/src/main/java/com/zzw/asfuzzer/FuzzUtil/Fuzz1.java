package com.zzw.asfuzzer.FuzzUtil;

import android.content.ComponentName;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Parcel;
import android.os.RemoteException;
import android.provider.ContactsContract;
import android.telecom.PhoneAccount;
import android.util.Log;

import com.zzw.asfuzzer.LogUtil;
import com.zzw.asfuzzer.ServiceUtil.GetContext;
import com.zzw.asfuzzer.ServiceUtil.GetService;
import com.zzw.asfuzzer.ServiceUtil.MyApplication;
import com.zzw.asfuzzer.ToolUtil.whitehelp;


import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import static com.zzw.asfuzzer.FuzzUtil.Fuzz1Util.getIntarray;

public class Fuzz1 implements Runnable{    //对一个参数进行fuzz
    private IBinder binder=null;
    private static String Errorinfo="";
    private int intercode;
    List list1 = new ArrayList();
    List list = new ArrayList();
    Getlistdata getstyle=new Getlistdata();
    private String ServiceName=null;
    private String description=null;
    public  Random rand=new Random();
    private static Handler handler;
    private static int ErrorTime=0;
    private static int service_count;
    HashMap<String,List> objmap= new HashMap<>();
    public int[] int_para={0,1,-1,Integer.MAX_VALUE,1234567,Integer.MIN_VALUE,rand.nextInt(),-1234567};
    public long[] long_para={0,1,-1,Long.MAX_VALUE,Long.MIN_VALUE,rand.nextLong()};
    public float[] float_para={0,1,-1,Float.MAX_VALUE,Float.MIN_VALUE,Float.MIN_NORMAL,Float.MAX_EXPONENT,Float.MIN_EXPONENT,rand.nextFloat()};
    public double[] double_para={0,1,-1,Double.MAX_EXPONENT,Double.MAX_VALUE,Double.MIN_EXPONENT,Double.MIN_NORMAL,Double.MIN_VALUE,3.1415926};
    public byte[] byte_para={0,1,101,-56,89,-89,-110,-1,Byte.MAX_VALUE,Byte.MIN_VALUE};
    public boolean[] bool_para={false,true};
    public String[] str_para={" ","abcd"};
    public static List bindlist=new ArrayList();
    public  List paralist=new ArrayList();
    public  void SetHandler(Handler handler){
        this.handler=handler;

    }


    public Fuzz1(List paralist){
        this.paralist.addAll(paralist);
        try {
            this.bindlist.addAll(DataUtil.getbinder());
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
    }
    /**
     * 集合里面的数据  1，binder 2.服务名  3.接口号 4.接口方法  5.参数1 6.参数2 7.参数3
     * 对于无参数的接口，重复调用。
     */
    public void run() {

        Message message = handler.obtainMessage();
        //1.为避免资源竞争之类，线程暂停0.3秒
        String st="接口方法---->" + paralist.get(3) + "  " + "接口号---->" + paralist.get(2) + "   " + "参数----->" + paralist.get(4)+"\n"+"开始测试";
        message.obj = st;
        handler.sendMessage(message);
        LogUtil.d("开始测试",st);
        Fuzz1Util.makeline(); //生成执行序列
        if(bindlist.size()==0){
            try {
                bindlist=DataUtil.getbinder();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (NoSuchMethodException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
        }
        String style = (String) getstyle.GetParaStyleRelation().get(paralist.get(4));
        if (style == null) {      //判断为非常规参数
            try {
                exec(25,10);
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (NoSuchMethodException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
        } else {
            try {
                Class<?> clazz = Class.forName("android.os.ServiceManager");
                service_count=GetService.GetServiceName(clazz).length;
                //bindlist=DataUtil.getbinder();
                DealStylePara(style);   //常规参数
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (NoSuchMethodException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
        }
    }
    public Object[] multiPara(String style){
        Object[] object=null;
        if(style.contains("[L")||style.contains("\\;")){
            style=style.substring(2, style.length()-1);
            Log.e("参数为数组",style+"");
        }
            try {
               object= Getinstance(style);         //非常规参数，获取实例
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            } catch (InstantiationException e) {
                e.printStackTrace();
            }
            return object;
        }

    public void DealStylePara(String style) throws ClassNotFoundException, NoSuchMethodException, IllegalAccessException, InvocationTargetException {
        int caseStyle= Integer.parseInt(style.split(" ")[1]);

        switch (caseStyle){
            case 1:
                //int 整型
                exec(1,1000);
                Log.e("type",1+"类型");
                break;
            case 2:
                //int[] 整型数组
                exec(2,256);
                Log.e("type",2+"类型");
                break;
            case 3:
                //byte 字节型
                GetContext.toastNews("没有构造字节型数据");
                break;
            case 4:
                exec(4,256);//byte[]数组类型
                Log.e("type",4+"类型");
                break;
            case 5:
                //long 长整型
                exec(5,1000);
                Log.e("type",5+"类型");
                break;
            case 6:
                //long[] 长整型数组
                Log.e("type",6+"类型");
                break;
            case 7:
                //float 浮点型
                exec(7,1000);
                Log.e("type",7+"类型");
                break;
            case 8:
                //float[] 浮点型数组
                exec(8,256);
                Log.e("type",8+"类型");
                break;
            case 9:
                //double 双精度型
                exec(9,1000);
                Log.e("type",9+"类型");
                break;
            case 10:
                //double[] 双精度型数组
                GetContext.toastNews("没有构造double数组数据");

                break;
            case 11:
                //boolean  布尔型
                exec(11,10);
                Log.e("type",11+"类型");
                break;
            case 12:
                //boolean[] 数组
                exec(12,31);
                Log.e("type",12+"类型");
                break;
            case 13: //字符串
                exec(13,800);
                Log.e("type",13+"类型");
                break;
            case 14:
                //String[]  字符串数组
                exec(14,256);
                Log.e("type",14+"类型");
                break;
            case 15:
                //Ibinder类型

                exec(15,2);
                Log.e("type",15+"类型");
                break;
            case 16:
                //bundle类型
                exec(16,1);
                Log.e("type",16+"类型");
                break;
            case 17:
                //intent 双精度型数组
                exec(17,48);
                Log.e("type",17+"类型");
                break;
            case 18:
                //intent[]数组
                GetContext.toastNews("没有构造intent数组数据");
                Log.e("type",18+"类型");
                break;
            case 19:
                //List
                exec(19,61);
                Log.e("type",19+"类型");
                break;
            case 20:
                //URI类型
                exec(20,22); //循环22次
                Log.e("type",20+"类型");
                break;
            case 21:
                //Map类型
                exec(21,1);
                Log.e("type",21+"类型");
                // 型
                break;
            case 22:
                //Content
                ContentValues values=new ContentValues();
                Log.e("type",22+"类型");
                break;
            case 23:
                //component类型
                exec(23,31);
                Log.e("type",23+"类型");
                break;
            case 24:
                //ComponentName数组
                exec(24,31);
                Log.e("type",24+"类型");
                break;


        }
    }
    public void exec(int num,int cycletimes) throws ClassNotFoundException, NoSuchMethodException, IllegalAccessException, InvocationTargetException {
        Message message = handler.obtainMessage();
        Object[]  obj=null;
        int objectlength=0;
        if(num==25){
            obj=multiPara((String) paralist.get(4));
            if(obj==null){
                objectlength=1;
            }
            else{
                objectlength=obj.length;
            }
        }
       int valueint=0;
        long valuelong=0;
        int[] valueIntarry=null;
        List valuelist=null;
        float[] valuefloatarray=null;
        IBinder valueBinder=null;
        Uri valueUri=null;
        boolean[] valueboolArry=null;
        float valuefloat=0;
        double valuedouble=0;
        Map valuemap=null;
        String[] valueStringArray=null;
        Intent  valueIntent = null;
        ComponentName valueComponent=null;
        byte[] bytearray=null;
        Bundle valuebundle=null;
        String valueString="";
       int nullcount=0;
       ComponentName[] componentarray=null;
       boolean valuebool;
        //2.获取binder，为避免binder失活，采取多种binder方案。
        binder = (IBinder) paralist.get(0);
        //3.获取服务名,获取接口描述符。
        ServiceName = (String) paralist.get(1);
        //4.获取接口号
        intercode = (int) paralist.get(2);
        //5.新建data和replay
        Parcel data = Parcel.obtain();
        Parcel reply = Parcel.obtain();
        //7.获取接口描述符。
        try {
            description=binder.getInterfaceDescriptor();
        } catch (RemoteException e) {
            Log.e("error","接口描述符错误");
            e.printStackTrace();
        }
        //8.写入接口描述符

        //9.写入参数其他

        for(int i=0;i<cycletimes;i++){  //调用50次
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            try {
                Log.e("日志","接口名---->"+paralist.get(3)+"  "+"接口号---->"+paralist.get(2)+"参数----->" + paralist.get(4));
                //6.生成接口描述符,首先判断是否失活
                if(binder==null){    //如果binder失活，获取binder
                    Log.d("BINDER","BINDER DEAD!!!");
                    try {
                        binder= GetService.getIBinder(ServiceName);
                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    } catch (NoSuchMethodException e) {
                        e.printStackTrace();
                    } catch (InvocationTargetException e) {
                        e.printStackTrace();
                    } catch (IllegalAccessException e) {
                        e.printStackTrace();
                    }
                }
                data.writeInterfaceToken(description); //写入描述符
                switch (num){
                    case 1:
                        valueint=Fuzz1Util.getInt();
                        Log.e("测试参数 int-->",valueint+"");
                        data.writeInt(valueint);
                        break;
                    case 2:
                        valueIntarry= getIntarray(i);
                        data.writeIntArray(valueIntarry);
                        Log.e("测试参数 int[]-->",valueIntarry+"");
                        break;
                    case 4:
                        bytearray=DataUtil.getByte(i);
                        Log.e("测试参数 byte[]-->", Arrays.toString(bytearray)+"");
                        data.writeByteArray(bytearray);
                        break;
                    case 5:
                        valuelong=Fuzz1Util.getLong();
                        data.writeLong(valuelong);
                        Log.e("测试参数 long-->", valuelong+"");
                        break;
                    case 7:
                        valuefloat=Fuzz1Util.getfloat();
                        data.writeFloat(valuefloat);
                        Log.e("测试参数 float-->", valuefloat+"");
                        break;
                    case 8:
                        valuefloatarray=DataUtil.getfloatarray(i);
                        data.writeFloatArray(valuefloatarray);
                        Log.e("测试参数 floatarray-->", valuefloatarray+"");
                        break;
                    case 9:
                        valuedouble=Fuzz1Util.getdouble();
                        data.writeDouble(valuedouble);
                        Log.e("测试参数 double-->", valuedouble+"");
                        break;
                    case  11:
                        valuebool=getBoolean();
                        Log.e("测试参数 boolean-->",valuebool+"");
                        data.writeValue(valuebool);
                        break;
                    case 12:
                        valueboolArry= DataUtil.getbooleanArray((i+1)%15);
                        data.writeBooleanArray(valueboolArry);
                        Log.e("测试参数 boolean[]-->",valueboolArry+"");
                        break;
                    case 13:
                        valueString=DataUtil.getRandomString((i+1)%40); //(i+1)%30
                        Log.e("测试参数 string-->",valueString+"");
                        data.writeString(valueString);
                        break;
                    case 14:
                        valueStringArray=DataUtil.getStrArray(i+1);
                        data.writeStringArray(valueStringArray);
                        Log.e("测试参数 string[]-->",valueStringArray+"");
                        break;
                    case 15:
                        valueBinder= (IBinder) bindlist.get(i+1);
                        data.writeStrongBinder(valueBinder);
                        Log.e("测试参数 binder-->",valueBinder+"");
                        break;
                    case 16:
                        valuebundle=DataUtil.GetBundle();
                        data.writeBundle(valuebundle);
                        Log.e("测试参数 bundle-->",valuebundle+"");
                        break;
                    case 17:
                        valueIntent=DataUtil.GetIntent(i);
                        Log.e("测试参数 intent-->",valueIntent+"");
                        data.writeValue(valueIntent);
                        break;
                    case 19:  //list类型数据
                        valuelist=DataUtil.getList((i+1)%10);
                        data.writeList(valuelist);
                        Log.e("测试参数 list-->",valuelist+"");
                        break;
                    case 20:
                        valueUri=DataUtil.GetUri();
                        data.writeValue(valueUri);
                        Log.e("测试参数 uri-->",valueUri+"");
                        break;
                    case 21:
                        valuemap=DataUtil.GetMap(i%21);
                        data.writeMap(valuemap);
                        Log.e("测试参数 map-->",valuemap+"");
                        break;
                    case 23:
                        valueComponent=DataUtil.getComPonentname(i);
                        data.writeValue(valueComponent);
                        Log.e("测试参数 component-->",valueComponent+"");
                        break;
                    case 24:
                        componentarray=DataUtil.getComponentArray(i);
                        data.writeArray(componentarray);
                        Log.e("测试参数 component[]-->",componentarray+"");
                        break;
                    case 25:
                            if(obj==null){
                                data.writeValue(null);
                                break;
                            }
                            else{
                                data.writeValue(obj[i%objectlength]);
                                Log.e("测试参数 Objectinstans>",obj[i%objectlength]+"");
                            }
//                            for(int c=0;c<objectlength;c++){
//                                if(obj[c]!=null){
//                                    data.writeValue(obj[c]);
//                                    Log.e("测试参数 Objectinstans>",obj[c]+"");
//                                }
//                            }
                            break;
                }
                boolean x=binder.transact(intercode,data,reply,0);
                Log.e("第一层校验",x+" ");
                reply.readException();
                reply.toString();
            } catch (Exception e) {

                Errorinfo=MyApplication.getStackTraceInfo(e);   //获取异常信息
                if(Errorinfo.contains("SecurityException")||Errorinfo.contains("NullPointerException") || Errorinfo.contains("android.os.DeadObjectException") ||Errorinfo.contains("android.permission")|| Errorinfo.contains("Neither user") || Errorinfo.contains("current process") || Errorinfo.contains("permision denied") || Errorinfo.contains("not allowed")){
                    ErrorTime+=1;          //异常计数
                    if(ErrorTime==1){   //第一次异常则写入数据库
                        LogUtil.e("打印异常","@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@开始打印异常@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
                        LogUtil.e("异常信息",MyApplication.getStackTraceInfo(e));
                        LogUtil.e("打印异常","@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@打印异常结束@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
                    }
                }
                e.printStackTrace();    //打印第一次异常
                Log.e("ERRORTIME",ErrorTime+"");
                whitehelp.WriteToWhitelist(paralist.get(3).toString(),ServiceName);  //如果发生异常，则将该测试方法写入数据库。
                LogUtil.e("ERROR","服务名 "+paralist.get(1)+"接口名-->"+paralist.get(3)+"  "+"接口号-->"+paralist.get(2)+" 参数-->"+paralist.get(4));
                LogUtil.e("ERROR 测试参数 int-->",""+valueint);
                LogUtil.e("ERROR 测试参数 string-->",""+valueString);
                LogUtil.e("ERROR 测试参数-->",""+paralist.get(4));
                LogUtil.e("ERROR 测试参数 byte-->", Arrays.toString(bytearray)+"");
                LogUtil.e("ERROR 测试参数 uri-->",valueUri+"");
                LogUtil.e("ERROR 测试参数 binder-->",valueBinder+"");
                LogUtil.e("ERROR 测试参数 component-->",valueComponent+"");
                LogUtil.e("ERROR 测试参数 intent-->",valueIntent+"");
                LogUtil.e("ERROR 测试参数 list-->",valuelist+"");
                LogUtil.e("ERROR 测试参数 string[]-->",valueStringArray+"");
                LogUtil.e("ERROR 测试参数 floatarry-->", valuefloatarray+"");
                LogUtil.e("ERROR 测试参数 long-->", valuelong+"");
                LogUtil.e("ERROR 测试参数 bundle-->",valuebundle+"");
                LogUtil.e("ERROR 测试参数 compont[]-->",componentarray+"");
                LogUtil.e("ERROR 测试参数 float-->", valuefloat+"");
                LogUtil.e("ERROR 测试参数 int[]-->",valueIntarry+"");
                LogUtil.e("ERROR 测试参数 double-->", valuedouble+"");
                LogUtil.e("ERROR 测试参数 map-->",valuemap+"");
                LogUtil.e("ERROR 测试参数 boolean[]-->", valueboolArry+"");
                LogUtil.e("ERROR 测试参数 Object>",obj+"");
                LogUtil.e("ERROR"," ################################################################################");
            }
            finally {
                data.recycle();
                reply.recycle();
                if(ErrorTime==100){
                    whitehelp.WriteToWhitelist(paralist.get(3).toString(),ServiceName);
                    break;
                }
            }

        }

        ErrorTime=0;//  该方法测试完结束，清零
       // whitehelp.WriteToWhitelist(paralist.get(3).toString(),ServiceName);
        message.arg1 = 1;

        message.obj = "测试结束    ";
        handler.sendMessage(message);


    }
/**
 *对参数进行处理
 *
 */



    public Object[] Getinstance(String Para) throws ClassNotFoundException, IllegalAccessException, InvocationTargetException, InstantiationException {
        Object[] object=null;
        Object obj=null;
        Class<?> cla = Class.forName(Para);
        Constructor<?>[] construct = cla.getConstructors();

        int len = construct.length;  //构造参数个数
        if (len == 0) {            //没有反射,直接参数为空。
            Log.e("re", "参数为空");
            return object;
        }
        else{
            object=new Object[len];
            Log.e("re", "有"+len+"个构造参数！");
            for(int j=0;j<len;j++){

                construct[j].setAccessible(true);
                Class<?>[] parame = construct[j].getParameterTypes();
                if(parame.length==0){
                    Log.e("构造",construct[j].getName());
                    Object obj0=construct[j].newInstance();     //空构造函数
                    object[j]=obj0;
                }
                else{
                    if(parame.length>5){
                        break;
                    }
                    for (Class para : parame) {
                        list1.add(para.getName());
                    }
                    for(int i=0;i<list1.size();i++){
                        String style = (String) Getlistdata.GetParaStyleRelation().get(list1.get(i));
//                        if(style==null){ //构造参数中有复杂参数，直接返回空
//                            flag=false;
//                            break;
//                        }
                        objmap = evaluatePara(style,i);
                    }
//                    if(flag==false){
//                        continue;
//                    }
                    Object[] ob=new Object[objmap.size()];
                    for(int k=0;k<objmap.size();k++){
                        ob[k]=objmap.get("para"+k).get(k);
                    }
                    obj=construct[j].newInstance(ob);
                    object[j]=obj;
                }
                list.clear();
                list1.clear();
                objmap.clear();
            }


            Log.e("类型",object.length+" ");
        }


        return object;
    }

    /**
     *
     * 处理对象数组中的参数，只保留常规数据类型。复杂类型则不考虑。
     * @param style
     * @param i
     * @return
     */

    public HashMap evaluatePara(String style,int i) {
        if(style==null){
            list.add(null);
            objmap.put("para"+i,list);
            return objmap;
        }
        int caseStyle= Integer.parseInt(style.split(" ")[1]);

        switch (caseStyle) {
            case 1:
                list.add(DataUtil.getRandomint(1,1000));
                objmap.put("para"+i,list);
                return objmap;
            //Log.e("type", 1 + "类型");
            case 2:
                int[] intarry=getIntarray(rand.nextInt(64));
                list.add(intarry);
                objmap.put("para"+i,list);
                return objmap;
            case 3:
                //byte 字节型
                int x=DataUtil.getRandomint(1,10);   //获取随机值，来定位byte数组中的数据。
                list.add(byte_para[x]);
                Log.e("type", 3 + "类型");
                break;
            case 4:
                //byte[] 字节数组
                byte[] bytearry=DataUtil.getbyteArry(rand.nextInt(64));
                list.add(bytearry);
                objmap.put("para"+i,list);
                return objmap;

            case 5:
                //long 长整型
                long long1=Fuzz1Util.getLong();
                list.add(long1);
                objmap.put("para"+i,list);
                return objmap;
            case 6:
                //long[] 长整型数组
                long []longarry=Fuzz1Util.getLongarray(rand.nextInt(64));
                list.add(longarry);
                objmap.put("para"+i,list);
                return objmap;
            case 7:
                //float 浮点型
                float float1=Fuzz1Util.getfloat();
                list.add(float1);
                objmap.put("para"+i,list);
                return objmap;

            case 8:
                float[] floatarry=DataUtil.getfloatarray(rand.nextInt(64));
                list.add(floatarry);
                objmap.put("para"+i,list);
                return objmap;
            case 9:
                double double1=Fuzz1Util.getdouble();
                list.add(double1);
                objmap.put("para"+i,list);
                return objmap;
            case 10:
                double[] doublearry=Fuzz1Util.getDoubleArry1(rand.nextInt(64));
                list.add(doublearry);
                objmap.put("para"+i,list);
                return objmap;
            case 11:
                list.add(getBoolean());
                objmap.put("para"+i,list);
                return objmap;
            case 12:
                boolean [] boolarry=DataUtil.getbooleanArray(rand.nextInt(16)+1);
                list.add(boolarry);
                objmap.put("para"+i,list);
                return objmap;
            case 13:
                //String 字符串型
                list.add(DataUtil.getRandomString(DataUtil.getRandomint(1,15)));
                objmap.put("para"+i,list);
                return objmap;
            case 14:
                String [] str=DataUtil.getStrArray(rand.nextInt(32)+1);
                list.add(str);
                objmap.put("para"+i,list);
                return objmap;
            case 15:
                IBinder binder1;

                binder1= (IBinder) bindlist.get(rand.nextInt(service_count)+1);
                list.add(binder1);

                objmap.put("para"+i,list);
                return objmap;
            case 17:
                //intent 双精度型数组
                Intent intent1=DataUtil.GetIntent(rand.nextInt(48)+1);
                list.add(intent1);
                objmap.put("para"+i,list);
                return objmap;
            case 18:
                //intent[]数组
                Intent[] intentarry=DataUtil.getintentarry(rand.nextInt(48)+1);
                list.add(intentarry);
                objmap.put("para"+i,list);
                return objmap;
            case 19://返回list类型
                list.add(DataUtil.getList((DataUtil.getRandomint(1,31))));
                objmap.put("para"+i,list);
                return objmap;
            case 20:
                //URI类型
                Uri uri1=DataUtil.GetUri();
                list.add(uri1);
                objmap.put("para"+i,list);
                return objmap;
            case 23:
                //URI类型
                list.add(DataUtil.getComPonentname(DataUtil.getRandomint(1,15)));
                objmap.put("para"+i,list);
                return objmap;
        }
        return objmap;
    }
    public  boolean getBoolean() {
        return Math.random() < 0.5 ? true : false;
    }

}
