package com.zzw.asfuzzer.FuzzUtil;

import android.content.Context;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.util.Log;


import com.zzw.asfuzzer.ServiceUtil.GetService;
import com.zzw.asfuzzer.ServiceUtil.MyApplication;
import com.zzw.asfuzzer.ToolUtil.whitehelp;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Getlistdata {
    public Class<?> clazz;
    String sql;
    private SQLiteDatabase db;
    private Context context;
    private Message msg;
    final ExecutorService Threadpool= Executors.newSingleThreadExecutor();
    private static String  whitelist="";
    public Fuzz0 fuzz0thread;

    private Fuzz1 fuzz1thread;
   // private Fuzz2 fuzz2thread;
    private Fuzzmore fuzzmorethread;
    private Fuzzshort fuzzshort;

    public void GetParafromSQL(String SN,Handler handler,int paranum) throws ClassNotFoundException, NoSuchMethodException, IllegalAccessException, InvocationTargetException {
        int interfacecode;
        int Para_num;
        String para;
        String interfacemethod;
        msg = handler.obtainMessage();

        List paraList=new ArrayList();
        clazz=Class.forName("android.os.ServiceManager");
        context= MyApplication.getMcontext();
        db=SQLiteDatabase.openDatabase(String.valueOf(context.getDatabasePath("ASFuzzer.db")),null,SQLiteDatabase.OPEN_READONLY);
        IBinder binder= GetService.getIBinder(SN);
        if(SN.contains(".")){
            SN=SN.replace(".","0");
        }
        whitelist= whitehelp.Getinvoke(SN);
        Log.e("白名单",whitelist);
        sql="SELECT * FROM "+SN;
        Cursor cursor=db.rawQuery(sql,null);
        int linenumber=cursor.getCount();  //获取表中多少行
        if(linenumber==0){
            msg.arg1 = 4;
            msg.obj = "   表空       没有测试项        ";
            handler.sendMessage(msg);
        }
        Para_num=cursor.getColumnCount();    //获取该表有多少列，方便后面获取参数
        if(linenumber!=0&&cursor.moveToNext()){
            do{
                paraList.add(binder);      //第一个元素binder
                paraList.add(SN);          //第二个元素服务名，防止binder死亡重新获取
                interfacecode=cursor.getInt(cursor.getColumnIndex("interfaceCode"));
                interfacemethod=cursor.getString(cursor.getColumnIndex("InterfaceName"));
                if(interfacecode==0&&linenumber==1){//如果表中只有一行，而且接口号为空，则赋值为1.
                    interfacecode=1;
                }
                if(interfacecode==0){//如果表中该行值为空即0，则清除数据，continue。进入下一循环。
                    paraList.clear();
                    continue;
                }
                paraList.add(interfacecode);  //接口号添加集合
                paraList.add(interfacemethod);    //接口方法名添加到集合

                //如果还有参数则将参数也添加进入集合中，
                for(int i=0;i<Para_num-4;i++){
                    para=cursor.getString(cursor.getColumnIndex("para" + i));
                    if(para!=null){
                        paraList.add(para);
                    }
                    else{
                        break;
                    }
                }
                if(whitelist.contains(paraList.get(3).toString())){
                    paraList.clear();
                    continue;
                }
                else{
                    GetParaStyle(paraList,handler,paranum);//传入了要执行的参数fuzz方法
                }
                paraList.clear();  //清空该行集合的数据
            }while(cursor.moveToNext());

        }
        cursor.close();

    }
    public void poolstop(){
        Threadpool.shutdown();
    }

    public  void GetParaStyle(List para,Handler handler,int fuzzstyle) {
        int paranum = para.size() - 4;
        if (paranum == fuzzstyle&&paranum!=3)
        {
            switch (fuzzstyle) {
                case 0:   //无参
                    fuzz0thread = new Fuzz0(para);
                    Threadpool.execute(fuzz0thread);
                    fuzz0thread.SetHandler(handler);
                    break;
                case 1:   //一个参数

                    fuzz1thread = new Fuzz1(para);
                    Threadpool.execute(fuzz1thread);
                    fuzz1thread.SetHandler(handler);
                    break;
                case 2:   //两个参数
                  fuzzshort=new Fuzzshort(para);
                  Threadpool.execute(fuzzshort);
                  fuzzshort.SetHandler(handler);

                    fuzzmorethread=new Fuzzmore(para);
                    Threadpool.execute(fuzzmorethread);
                    fuzzmorethread.SetHandler(handler);
                    break;
            }
        }
        if(fuzzstyle==3&&paranum>=fuzzstyle){
            fuzzshort=new Fuzzshort(para);
            Threadpool.execute(fuzzshort);
            fuzzshort.SetHandler(handler);

            fuzzmorethread=new Fuzzmore(para);
            Threadpool.execute(fuzzmorethread);
            fuzzmorethread.SetHandler(handler);
        }
    }
    public static HashMap GetParaStyleRelation(){
        HashMap<String,String>  ParaStyleRelation=new HashMap<>();


        ParaStyleRelation.put("int","int 1");  //数据库，真实类型
        ParaStyleRelation.put("[I;","int[] 2");

        ParaStyleRelation.put("byte","byte 3");
        ParaStyleRelation.put("[B","byte[] 4");


        ParaStyleRelation.put("long","long 5");
        ParaStyleRelation.put("[J","long[] 6");

        ParaStyleRelation.put("float","float 7");
        ParaStyleRelation.put("[F","float[] 8");

        ParaStyleRelation.put("double","Double 9");
        ParaStyleRelation.put("[D","Double[] 10");

        ParaStyleRelation.put("boolean","boolean 11");
        ParaStyleRelation.put("[Z","boolean[] 12");

        ParaStyleRelation.put("java.lang.String","String 13");
        ParaStyleRelation.put("[Ljava.lang.String;","String[] 14");

        ParaStyleRelation.put("android.os.IBinder","IBinder 15");   //服务的各种服务IBinder

        ParaStyleRelation.put("android.os.Bundle", "Bundle 16");//新建数据bundle，添加各种数据，以基本数据类型为主、
        ParaStyleRelation.put("android.content.Intent","intent 17"); //intent可以构造空，打电话
        ParaStyleRelation.put("[Landroid.content.Intent;","intent[] 18");
        ParaStyleRelation.put("java.util.List","List 19");
        ParaStyleRelation.put("android.net.Uri","URI 20");
        ParaStyleRelation.put("java.util.Map","Map 21");
        ParaStyleRelation.put("android.content.ContentValues","content 22");
        ParaStyleRelation.put("android.content.ComponentName","ComponentName 23");
        ParaStyleRelation.put("[Landroid.content.ComponentName;","ComponentName 24");


        return ParaStyleRelation;
    }


}
