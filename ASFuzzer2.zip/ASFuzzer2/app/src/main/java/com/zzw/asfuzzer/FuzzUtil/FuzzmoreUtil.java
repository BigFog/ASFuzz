package com.zzw.asfuzzer.FuzzUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class FuzzmoreUtil {
    private static ArrayList<String> tmpArr = new ArrayList<>();
    static List linelist=new ArrayList();

    public static HashMap ParaStylePriority(){        //变异优先级排列
        HashMap<String,String>  Stylepriority=new HashMap<>();//优先变异的顺序，容易构造的，数量小的排在前，2
        Stylepriority.put("boolean","boolean 1");
        Stylepriority.put("byte","byte 2");
        Stylepriority.put("android.content.ComponentName","ComponentName 3");
        Stylepriority.put("android.net.Uri","URI 4");
        Stylepriority.put("android.os.IBinder","IBinder 5");
        Stylepriority.put("android.content.Intent","intent 6"); //intent可以构造空，打电话
        Stylepriority.put("[Z","boolean[] 7");
        Stylepriority.put("int","int 8");        //数据库，真实类型
        Stylepriority.put("java.lang.String","String 9");
        Stylepriority.put("[B","byte[] 10");
        Stylepriority.put("long","long 11");
        Stylepriority.put("float","float 12");
        Stylepriority.put("double","Double 13");
        Stylepriority.put("[I;","int[] 14");
        Stylepriority.put("[J","long[] 15");
        Stylepriority.put("[Ljava.lang.String;","String[] 16");
        Stylepriority.put("[Landroid.content.Intent;","intent[] 17");
        Stylepriority.put("java.util.List","List 18");
        Stylepriority.put("[Landroid.content.ComponentName;","ComponentName[] 19");
        Stylepriority.put("[F","float[] 20");
        Stylepriority.put("[D","Double[] 21");
        Stylepriority.put("android.os.Bundle", "Bundle 22");
        Stylepriority.put("java.util.Map","Map 23");
        Stylepriority.put("Object","object 24");
        Stylepriority.put("android.content.ContentValues","values 25");
        return Stylepriority;
    }
    public static void clearlist(){
        linelist.clear();
    }

    /**
     * 获取执行变异序列，该数据不可变
     *
     * @param num
     */

    public static void GetChangeline(String [] num) {
        String [] line=num;
        int len=num.length;
        for(int j=1;j<len+1;j++) {
            combine(0 ,j ,num);
        }
    }
    public static void combine(int index,int k,String []arr) {

        if(k == 1){
            for (int i = index; i < arr.length; i++) {
                tmpArr.add(arr[i]);
                // System.out.print(tmpArr.toString() + ",");
                linelist.add(tmpArr.toString());
                tmpArr.remove((Object)arr[i]);
            }
        }else if(k > 1){
            for (int i = index; i <= arr.length - k; i++) {
                tmpArr.add(arr[i]); //tmpArr都是临时性存储一下
                combine(i + 1,k - 1, arr); //索引右移，内部循环，自然排除已经选择的元素
                tmpArr.remove((Object)arr[i]); //tmpArr因为是临时存储的，上一个组合找出后就该释放空间，存储下一个元素继续拼接组合了
            }
        }else{
            return ;
        }

    }


    /**
     *
     * 下面两个方法用来确定每次变异的序列，根据优先级。
     * @param com
     * @return
     */
    public static String[] sort(String[] com) {
        int len=com.length;
        for(int i=0;i<len;++i) {
            boolean flag=false;
            for(int j=0;j<len-i-1;++j) {
                if(compare(com[j],com[j+1])) {
                    String temp=com[j];
                    com[j]=com[j+1];
                    com[j+1]=temp;
                    flag=true;
                }
            }
            if(!flag) {
                break;
            }
        }
        return com;
    }
    public static boolean compare(String one,String two) {
        boolean flag=true;
        if(Integer.valueOf(one.split("-")[0])>Integer.valueOf(two.split("-")[0])) {
            flag=true;
        }
        else if(Integer.valueOf(one.split("-")[0])==Integer.valueOf(two.split("-")[0])) {
            if(one.split("-")[1].compareTo(two.split("-")[1])<0) {
                flag=false;
            }
        }
        else {
            flag=false;
        }
        return flag;
    }

    /**
     *
     * 下面两个方法用来获取每种变异有几个如  C 4 2 [4,6,4,1]
     * @param len
     * @return
     */
    public static int[] calculate(int len) {
        int [] backnum=new int[len];
        for(int i=0;i<len;i++) {
            backnum[i]=comb(len,i+1);
        }
        return backnum;
    }
    public static int comb(int m,int n){
        if(n==0) {
            return 1;
        }
        if (n==1) {
            return m;
        }
        if(n>m/2) {
            return comb(m,m-n);
        }
        if(n>1) {
            return comb(m-1,n-1)+comb(m-1,n);
        }
        return 0;
    }

    public static String[] GetsingleChangePoint(int groupNum,int[] num){
        String[] back=new String[num[groupNum]];
        int start=0;
        if(groupNum==0) {
            start=0;
        }
        else {
            for(int j=0;j<groupNum;j++) {
                start=start+num[j];
            }
        }
        for(int i=0;i<num[groupNum];i++) {
            back[i]=(String) linelist.get(start+i);
        }

        return back;
    }
}
