package com.zzw.asfuzzer.FuzzUtil;

import android.content.ComponentName;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Parcel;
import android.os.RemoteException;
import android.provider.ContactsContract;
import android.provider.Settings;
import android.util.Log;

import com.zzw.asfuzzer.LogUtil;
import com.zzw.asfuzzer.ServiceUtil.GetService;
import com.zzw.asfuzzer.ServiceUtil.MyApplication;
import com.zzw.asfuzzer.ToolUtil.whitehelp;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class Fuzzmore implements Runnable {
    Fuzz2Util fuzzmore=new Fuzz2Util();
    private static Handler handler;
    Object [] obj;
    int objtime=0;
    int Exceptiontime=0;
    int Errortime=0;
    static int service_count2;
    String Errorinfo2;
    int intercodeMore;
    String  ServiceNameMore;
    IBinder binderMore;
    String paraString;
    Random rand =new Random();
    public Message message;
    List saveParalist=new ArrayList();
    HashMap<String,Object> TempDataMap=new HashMap<>();
    public List paralist=new ArrayList();
    private static List Binderlist=new ArrayList();

    public  void SetHandler(Handler handler){
        this.handler=handler;
    }
    public Fuzzmore(List paralist) {
        this.paralist.addAll(paralist);
        try {
            Binderlist=DataUtil.getbinder();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
    }
    @Override
    public void run() {
        message=handler.obtainMessage();
        paraString="接口方法-->"+paralist.get(3)+"  接口号-->"+paralist.get(2);
        for(int i=0;i<paralist.size()-4;i++){
            paraString=paraString+" 参数"+(i+1)+"-->"+paralist.get(i+4);
        }
        String para=paraString+"\n开始测试";
        message.arg1=3;
        message.obj=para;
        handler.sendMessage(message);
        LogUtil.d("开始测试",para);
        Fuzz2Util.makeline(); //生成执行序列
        String []execline=getStyleNum();   //{12a 2b 4c 6a}
        try {
            Class<?> clazz = Class.forName("android.os.ServiceManager");
            service_count2=GetService.GetServiceName(clazz).length;
            executefuzz(execline);
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static IBinder GetBinder(int i) throws ClassNotFoundException, NoSuchMethodException, InvocationTargetException, IllegalAccessException {

        Class<?> clazz=Class.forName("android.os.ServiceManager");
        String[] ServiceName = GetService.GetServiceName(clazz);
        for(String SN:ServiceName) {
            IBinder bind=GetService.getIBinder(SN);
            Binderlist.add(bind);
        }
        return (IBinder) Binderlist.get(i);
    }

    public void executefuzz(String[] execline) throws InterruptedException, ClassNotFoundException, NoSuchMethodException, IllegalAccessException, InvocationTargetException, RemoteException {
        int valueIntmore;
        int[] valueIntArray;
        String valueStringMore;
        String[] valueStringArray;
        Bundle valueBundleMore;
        boolean valueboolMore;
        boolean []valueboolArry;
        byte valuebyteMore;
        byte[] valuebyteArry;
        Intent valueintent;
        Intent[] valueIntentArray;
        long valuelongMore;
        long[] valuelongArray;
        float valuefloatMore;
        float[] valuefloatArray;
        double valuedoubleMore;
        double[] valuedoubleArray;
        Object valueobjMore;
        Map valuemap;
        List valuelist;
        ComponentName valuecomponent;
        ComponentName[] valueComponentArray;
        Uri valueUri;
        IBinder valuebinder;
        String descriptionMore;
        boolean flag=true;
        List backresult=new ArrayList();
        binderMore= (IBinder) paralist.get(0);  //获取传入paralist中的binder
        ServiceNameMore= (String) paralist.get(1); //获取传入paralist中的服务名
        intercodeMore= (int) paralist.get(2);      //获取传入的接口号
        Parcel data = Parcel.obtain();
        Parcel reply2More= Parcel.obtain();
        int datalen=execline.length;                             //参数长度
        int [] groupdatanum=FuzzmoreUtil.calculate(datalen);     //每种变异位的个数
        String[] com=execline.clone();
        com=FuzzmoreUtil.sort(com);
        //克隆后对参数排序，对变异位排序
        FuzzmoreUtil.clearlist();
        descriptionMore=binderMore.getInterfaceDescriptor();     //获取接口描述符
        TempDataMap.clear();  //清空Tempdatamap
//        Errortime=0;
//        Exceptiontime=0;
        // 清空上一轮的临时值保存舱
        for(int stylecount=0;stylecount<execline.length;stylecount++){
            //执行序列在所有变异都不会变，只有变异位发生变化。
            FuzzmoreUtil.GetChangeline(com);
            String[] changepoint=FuzzmoreUtil.GetsingleChangePoint(stylecount,groupdatanum);   //获取该轮所使用的变异序列
            Log.e("变异序列：",DataUtil.StringArrayToString(changepoint));
            int grouplen=changepoint.length;                                                   //变异数组长度
            for(int exectimes=0;exectimes<400;exectimes++){    //对每种类型的变异进行500次循环变异
                //变异位点 //
                Thread.sleep(300);   //每次运行前停顿0.3秒，保证不争抢资源
                if(!backresult.isEmpty()){//非空
                    if(backresult.size()==1){
                        if(backresult.get(0).toString()=="false"){
                            Errortime+=1;
                        }
                        else{
                            String Errortext=backresult.get(0).toString();
                            if( Errortext.contains("SecurityException")||Errortext.contains("IllegalStateException")||Errortext.contains("NullPointerException")||Errortext.contains("BadParcelableException")||Errortext.contains("IllegalArgumentException") || Errortext.contains("android.os.DeadObjectException") ||Errortext.contains("android.permission")|| Errortext.contains("Neither user") || Errortext.contains("current process") || Errortext.contains("permision denied") || Errortext.contains("not allowed")){
                                Exceptiontime+=1;
                            }
                        }
                      }
                    if(backresult.size()==2) {
                        if(backresult.get(0).toString()=="false"){
                            Errortime+=1;
                        }
                        String Errortext = backresult.get(1).toString();
                        if (Errortext.contains("SecurityException")||Errortext.contains("IllegalStateException")||Errortext.contains("NullPointerException")||Errortext.contains("BadParcelableException")||Errortext.contains("IllegalArgumentException")||(Errortext.contains("android.permission") || Errortext.contains("android.os.DeadObjectException") || Errortext.contains("Neither user") || Errortext.contains("current process") || Errortext.contains("permision denied") || Errortext.contains("not allowed"))) {
                            Exceptiontime += 1;
                        }
                    }
                    Log.e("moretime",Errortime+"   "+Exceptiontime);
                    if(Errortime==10||Exceptiontime==100){
                        Log.e("次数到了",Errortime+""+Exceptiontime);
                        whitehelp.WriteToWhitelist(paralist.get(3).toString(),ServiceNameMore);
                        flag=false;
                        Errortime=1;
                        Exceptiontime=1;    //如果错误次数达到，则将time置为0.因为是全局变量。
                        break;
                    }
                }
                if(binderMore==null) {//每次运行前首先判断binder是否失活
                    Log.e("BINDER失活失活","BINDER DEAD!!!binder失活");
                    binderMore= GetService.getIBinder(ServiceNameMore);
                }
                data.writeInterfaceToken(descriptionMore);
                for(int exec=0;exec<execline.length;exec++){
                    String keyStr=execline[exec];                    //获取执行序列的值
                    int num=Integer.valueOf(keyStr.split("-")[0]);  //或取执行序列号
                                //写入接口描述符
                    switch (num){
                        case 1:  //boolean
                            if(TempDataMap.get(keyStr)==null){   //判断临时存储舱是否有保存的值
                                valueboolMore=false;              //没有值的话则设置初值，并写入存储舱保存
                                TempDataMap.put(keyStr,valueboolMore);
                            }
                            if(changepoint[exectimes%grouplen].contains(keyStr)){  //判断当前值是否对应变异
                                valueboolMore=DataUtil.getBoolean();          //如果是变异点，则进行变异
                                TempDataMap.put(keyStr,valueboolMore);        //并将变异结果写入临时存储
                            }
                                               //以上措施，保证临时存储舱都有数据。及有效数据遗传入下一轮数据
                            valueboolMore= (boolean) TempDataMap.get(keyStr);  //
                            data.writeValue(valueboolMore);
                            saveParalist.add(valueboolMore);
                            Log.e("测试参数 boolean:",keyStr+" "+valueboolMore);
                            break;
                        case 2:
                            if(TempDataMap.get(keyStr)==null){
                                valuebyteMore=100;
                                TempDataMap.put(keyStr,valuebyteMore);
                            }
                            if(changepoint[exectimes%grouplen].contains(keyStr)){
                                valuebyteMore=DataUtil.getBytevalue(rand.nextInt(255)%255);
                                TempDataMap.put(keyStr,valuebyteMore);
                            }
                            valuebyteMore= (byte) TempDataMap.get(keyStr);
                            data.writeByte(valuebyteMore);
                            saveParalist.add(valuebyteMore);
                            Log.e("测试参数 byte:",keyStr+" "+valuebyteMore);
                            break;
                        case 3:  //component
                            if(TempDataMap.get(keyStr)==null){
                                valuecomponent=new ComponentName("com.android.phone","com.android.phone.SimContacts");
                                TempDataMap.put(keyStr,valuecomponent);
                            }
                            if(changepoint[exectimes%grouplen].contains(keyStr)){
                                valuecomponent=DataUtil.getComPonentname(exectimes%31);
                                TempDataMap.put(keyStr,valuecomponent);
                            }
                            valuecomponent= (ComponentName) TempDataMap.get(keyStr);
                            data.writeValue(valuecomponent);
                            saveParalist.add(valuecomponent);
                            Log.e("测试参数 component:",keyStr+" "+valuecomponent);
                            break;
                        case 4:  //uri
                            if(TempDataMap.get(keyStr)==null){
                                valueUri=null;
                                TempDataMap.put(keyStr,valueUri);
                            }
                            if(changepoint[exectimes%grouplen].contains(keyStr)){
                                valueUri=DataUtil.GetUri();
                                TempDataMap.put(keyStr,valueUri);
                            }
                            valueUri= (Uri) TempDataMap.get(keyStr);
                            data.writeValue(valueUri);
                            saveParalist.add(valueUri);
                            Log.e("测试参数 uri:",keyStr+" "+valueUri);
                            break;
                        case 5: //ibinder
                            if(Binderlist.size()==0){
                                try {
                                    Binderlist=DataUtil.getbinder();
                                } catch (ClassNotFoundException e) {
                                    e.printStackTrace();
                                } catch (NoSuchMethodException e) {
                                    e.printStackTrace();
                                } catch (IllegalAccessException e) {
                                    e.printStackTrace();
                                } catch (InvocationTargetException e) {
                                    e.printStackTrace();
                                }
                            }
                            if(TempDataMap.get(keyStr)==null){
                                valuebinder= (IBinder) Binderlist.get(1);
                                TempDataMap.put(keyStr,valuebinder);
                            }
                            if(changepoint[exectimes%grouplen].contains(keyStr)){
                                valuebinder= (IBinder) Binderlist.get(exectimes%service_count2);
                                TempDataMap.put(keyStr,valuebinder);
                            }
                            valuebinder= (IBinder) TempDataMap.get(keyStr);
                            data.writeStrongBinder(valuebinder);
                            saveParalist.add(valuebinder);
                            Log.e("测试参数 ibinder:",keyStr+" "+valuebinder);
                            break;
                        case 6:   //intent
                            if(TempDataMap.get(keyStr)==null){
                                valueintent=new Intent(Intent.ACTION_CALL_BUTTON);
                                TempDataMap.put(keyStr,valueintent);
                            }
                            if(changepoint[exectimes%grouplen].contains(keyStr)){
                                valueintent=DataUtil.GetIntent(exectimes%48);
                                TempDataMap.put(keyStr,valueintent);
                            }

                            valueintent= (Intent) TempDataMap.get(keyStr);
                            data.writeValue(valueintent);
                            saveParalist.add(valueintent);
                            Log.e("测试参数 intent:",keyStr+" "+valueintent);
                            break;
                        case 7:    //boolean[]
                            if(TempDataMap.get(keyStr)==null){
                                valueboolArry=new boolean[]{true,false};
                                TempDataMap.put(keyStr,valueboolArry);
                            }
                            if(changepoint[exectimes%grouplen].contains(keyStr)){
                                valueboolArry=DataUtil.getbooleanArray((exectimes+1)%32);
                                TempDataMap.put(keyStr,valueboolArry);
                            }
                            valueboolArry= (boolean[]) TempDataMap.get(keyStr);
                            data.writeBooleanArray(valueboolArry);
                            saveParalist.add(valueboolArry);
                            Log.e("测试参数 boolean:",keyStr+" "+valueboolArry);
                            break;
                        case 8:   //int类型
                            if(TempDataMap.get(keyStr)==null)
                            {
                                valueIntmore=1;
                                TempDataMap.put(keyStr,valueIntmore);
                            }
                            if(changepoint[exectimes%grouplen].contains(keyStr)){ //判断是否为变异点
                                valueIntmore=Fuzz2Util.getInt();    //变异结束需要把数据写入tempDatamap
                                TempDataMap.put(keyStr,valueIntmore);
                            }
                             //如果不是变异点，则获取原值
                            valueIntmore= (int) TempDataMap.get(keyStr);
                            data.writeInt(valueIntmore);
                            saveParalist.add(valueIntmore);
                            Log.e("测试参数 int:",keyStr+" "+valueIntmore);
                            break;
                        case 9: //string
                            if(TempDataMap.get(keyStr)==null){
                                valueStringMore="abcd";
                                TempDataMap.put(keyStr,valueStringMore);
                            }
                            if(changepoint[exectimes%grouplen].contains(keyStr)){
                                valueStringMore=DataUtil.getRandomString((exectimes+1)%64);
                                TempDataMap.put(keyStr,valueStringMore);
                            }
                            valueStringMore= (String) TempDataMap.get(keyStr);
                            data.writeString(valueStringMore);
                            saveParalist.add(valueStringMore);
                            Log.e("测试参数 string:",keyStr+" "+valueStringMore);
                            break;
                        case 10: //byte[]
                            if((TempDataMap.get(keyStr)==null)){
                                valuebyteArry=new byte[]{0,1,-1,Byte.MIN_VALUE,Byte.MIN_VALUE};
                                TempDataMap.put(keyStr,valuebyteArry);
                            }
                            if(changepoint[exectimes%grouplen].contains(keyStr)){
                                valuebyteArry=DataUtil.getbyteArry((exectimes+1)%64);
                                TempDataMap.put(keyStr,valuebyteArry);
                            }
                            valuebyteArry= (byte[]) TempDataMap.get(keyStr);
                            data.writeByteArray(valuebyteArry);
                            saveParalist.add(valuebyteArry);
                            Log.e("测试参数 byte[]:",keyStr+" "+valuebyteArry);
                            break;
                        case 11:   //long
                            if(TempDataMap.get(keyStr)==null){
                                valuelongMore=1;
                                TempDataMap.put(keyStr,valuelongMore);
                            }
                            if(changepoint[exectimes%grouplen].contains(keyStr)){
                                valuelongMore=Fuzz2Util.getLong();
                                TempDataMap.put(keyStr,valuelongMore);
                            }
                            valuelongMore= (long) TempDataMap.get(keyStr);
                            data.writeLong(valuelongMore);
                            saveParalist.add(valuelongMore);
                            Log.e("测试参数 long:",keyStr+" "+valuelongMore);
                            break;
                        case 12:   //float
                            if(TempDataMap.get(keyStr)==null){
                                valuefloatMore=1f;
                                TempDataMap.put(keyStr,valuefloatMore);
                            }
                            if(changepoint[exectimes%grouplen].contains(keyStr)){
                                valuefloatMore=Fuzz2Util.getfloat();
                                TempDataMap.put(keyStr,valuefloatMore);
                            }
                            valuefloatMore= (float) TempDataMap.get(keyStr);
                            data.writeFloat(valuefloatMore);
                            saveParalist.add(valuefloatMore);
                            Log.e("测试参数 float:",keyStr+" "+valuefloatMore);
                            break;
                        case 13:   //double
                            if(TempDataMap.get(keyStr)==null){
                                valuedoubleMore=1;
                                TempDataMap.put(keyStr,valuedoubleMore);
                            }
                            if(changepoint[exectimes%grouplen].contains(keyStr)){
                                valuedoubleMore=Fuzz2Util.getdouble();
                                TempDataMap.put(keyStr,valuedoubleMore);
                            }
                            valuedoubleMore= (double) TempDataMap.get(keyStr);
                            data.writeDouble(valuedoubleMore);
                            saveParalist.add(valuedoubleMore);
                            Log.e("测试参数 double:",keyStr+" "+valuedoubleMore);
                            break;
                        case 14:  //int[]
                            if(TempDataMap.get(keyStr)==null){
                                valueIntArray=new int[]{0,1,-1,Integer.MIN_VALUE,Integer.MAX_VALUE};
                                TempDataMap.put(keyStr,valueIntArray);
                            }
                            if(changepoint[exectimes%grouplen].contains(keyStr)){
                                valueIntArray=Fuzz2Util.getIntarray((exectimes+1)%96);
                                TempDataMap.put(keyStr,valueIntArray);
                            }
                            valueIntArray= (int[]) TempDataMap.get(keyStr);
                            data.writeIntArray(valueIntArray);
                            saveParalist.add(valueIntArray);
                            Log.e("测试参数 int[]:",keyStr+" "+valueIntArray);
                            break;
                        case 15:  //long[]
                            if(TempDataMap.get(keyStr)==null){
                                valuelongArray=new long[]{0,1,-1,Long.MAX_VALUE,Long.MIN_VALUE};
                                TempDataMap.put(keyStr,valuelongArray);
                            }
                            if(changepoint[exectimes%grouplen].contains(keyStr)){
                                valuelongArray=Fuzz2Util.getLongarray((exectimes+1)%64);
                                TempDataMap.put(keyStr,valuelongArray);
                            }
                            valuelongArray= (long[]) TempDataMap.get(keyStr);
                            data.writeLongArray(valuelongArray);
                            saveParalist.add(valuelongArray);
                            Log.e("测试参数 long[]:",keyStr+" "+valuelongArray);
                            break;
                        case 16:   //String[]
                            if(TempDataMap.get(keyStr)==null){
                                valueStringArray=new String[]{" ","123","abcd"};
                                TempDataMap.put(keyStr,valueStringArray);
                            }
                            if(changepoint[exectimes%grouplen].contains(keyStr)){
                                valueStringArray=DataUtil.getStrArray((exectimes+1)%64);
                                TempDataMap.put(keyStr,valueStringArray);
                            }
                            valueStringArray= (String[]) TempDataMap.get(keyStr);
                            data.writeStringArray(valueStringArray);
                            saveParalist.add(valueStringArray);
                            Log.e("测试参数 string[]:",keyStr+" "+valueStringArray);
                            break;
                        case 17:    //intent[]
                            if(TempDataMap.get(keyStr)==null){
                                valueIntentArray=new Intent[]{new Intent(Settings.ACTION_SETTINGS),new Intent(Intent.ACTION_CAMERA_BUTTON,null)};
                                TempDataMap.put(keyStr,valueIntentArray);
                            }
                            if(changepoint[exectimes%grouplen].contains(keyStr)){
                                valueIntentArray=DataUtil.getintentarry((exectimes+1)%64);
                                TempDataMap.put(keyStr,valueIntentArray);
                            }
                            valueIntentArray= (Intent[]) TempDataMap.get(keyStr);
                            data.writeArray(valueIntentArray);
                            saveParalist.add(valueIntentArray);
                            Log.e("测试参数 intent[]:",keyStr+" "+valueIntentArray);
                            break;
                        case 18:   //list
                            if(TempDataMap.get(keyStr)==null){
                                valuelist=DataUtil.getList(1);
                                TempDataMap.put(keyStr,valuelist);
                            }
                            if(changepoint[exectimes%grouplen].contains(keyStr)){
                                valuelist=DataUtil.getList(exectimes%30);
                                TempDataMap.put(keyStr,valuelist);
                            }
                            valuelist= (List) TempDataMap.get(keyStr);
                            data.writeList(valuelist);
                            saveParalist.add(valuelist);
                            Log.e("测试参数 list:",keyStr+" "+valuelist);
                            break;
                        case 19:   //component[]
                            if(TempDataMap.get(keyStr)==null){
                                valueComponentArray=new ComponentName[]{new ComponentName("com.android.phone","com.android.phone.CallFeaturesSetting"),new ComponentName("com.android.phone","com.android.phone.SimContacts")};
                                TempDataMap.put(keyStr,valueComponentArray);
                            }
                            if(changepoint[exectimes%grouplen].contains(keyStr)){
                                valueComponentArray=DataUtil.getComponentArray((exectimes+1)%31);
                                TempDataMap.put(keyStr,valueComponentArray);
                            }
                            valueComponentArray= (ComponentName[]) TempDataMap.get(keyStr);
                            data.writeArray(valueComponentArray);
                            saveParalist.add(valueComponentArray);
                            Log.e("测试参数 component[]:",keyStr+" "+valueComponentArray);
                            break;
                        case 20:    //float[]
                            if(TempDataMap.get(keyStr)==null){
                                valuefloatArray=new float[]{0,1,-1,Float.MIN_NORMAL,Float.MAX_VALUE,Float.MIN_VALUE};
                                TempDataMap.put(keyStr,valuefloatArray);
                            }
                            if(changepoint[exectimes%grouplen].contains(keyStr)){
                                valuefloatArray=DataUtil.getfloatarray(exectimes%64);
                                TempDataMap.put(keyStr,valuefloatArray);
                            }
                            valuefloatArray= (float[]) TempDataMap.get(keyStr);
                            data.writeFloatArray(valuefloatArray);
                            saveParalist.add(valuefloatArray);
                            Log.e("测试参数 float[]:",keyStr+" "+valuefloatArray);
                            break;
                        case 21:  //double[]
                            if(TempDataMap.get(keyStr)==null){
                                valuedoubleArray=new double[]{0,1,-1,Double.MIN_VALUE,Double.MAX_VALUE};
                                TempDataMap.put(keyStr,valuedoubleArray);
                            }
                            if(changepoint[exectimes%grouplen].contains(keyStr)){
                                valuedoubleArray=Fuzz2Util.getDoubleArry((exectimes+1)%64);
                                TempDataMap.put(keyStr,valuedoubleArray);
                            }
                            valuedoubleArray= (double[]) TempDataMap.get(keyStr);
                            data.writeDoubleArray(valuedoubleArray);
                            saveParalist.add(valuedoubleArray);
                            Log.e("测试参数 double[]:",keyStr+" "+valuedoubleArray);
                            break;
                        case 22:    //特殊 bundle
                            if(TempDataMap.get(keyStr)==null){
                                valueBundleMore= DataUtil.GetBundle();
                                TempDataMap.put(keyStr,valueBundleMore);
                            }
                            if(changepoint[exectimes%grouplen].contains(keyStr)){
                                valueBundleMore= (Bundle) TempDataMap.get(keyStr);
                                TempDataMap.put(keyStr,valueBundleMore);
                            }
                            valueBundleMore= (Bundle) TempDataMap.get(keyStr);
                            data.writeBundle(valueBundleMore);
                            saveParalist.add(valueBundleMore);
                            Log.e("测试参数 bundle:",keyStr+" "+valueBundleMore);
                            break;
                        case 23:   //map
                            if(TempDataMap.get(keyStr)==null){
                                valuemap=DataUtil.GetMap(1);
                                TempDataMap.put(keyStr,valuemap);
                            }
                            if(changepoint[exectimes%grouplen].contains(keyStr)){
                                valuemap=DataUtil.GetMap((exectimes+1)%21);
                                TempDataMap.put(keyStr,valuemap);
                            }
                            valuemap= (Map) TempDataMap.get(keyStr);
                            data.writeMap(valuemap);
                            saveParalist.add(valuemap);
                            Log.e("测试参数 map:",keyStr+" "+valuemap);
                            break;
                        case 24:
                            int index=keyStr.charAt(3)-61;
                            if(objtime==0){
                                obj=fuzzmore.MultiPara((String) paralist.get(index));
                                objtime+=1;
                            }

                            if(TempDataMap.get(keyStr)==null){
                                if(obj==null){
                                    valueobjMore=null;
                                    TempDataMap.put(keyStr,valueobjMore);
                                }
                                else{
                                    valueobjMore=obj[0];
                                    TempDataMap.put(keyStr,valueobjMore);
                                }
                            }
                            if(changepoint[exectimes%grouplen].contains(keyStr)){
                                Log.e("变异","发生变异！");
                                if(obj==null){
                                    valueobjMore=null;
                                    TempDataMap.put(keyStr,valueobjMore);
                                }
                                else{
                                    valueobjMore=obj[rand.nextInt(obj.length)];
                                    TempDataMap.put(keyStr,valueobjMore);
                                }
                            }
                            valueobjMore=TempDataMap.get(keyStr);
                            data.writeValue(valueobjMore);
                            saveParalist.add(valueobjMore);
                            Log.e("测试参数 object:",keyStr+" "+valueobjMore);
                            break;
                        case 25:
                            ContentValues initialValues = new ContentValues();
                            data.writeValue(initialValues);
                            saveParalist.add(initialValues);
                            break;
                    }
                }
                backresult=execTransact(binderMore,intercodeMore,data,reply2More);
                saveParalist.clear();
                data.recycle();
                reply2More.recycle();

            }
            if(flag==false){
                break;
            }
        }

        whitehelp.WriteToWhitelist(paralist.get(3).toString(),ServiceNameMore);     //写入数据库
        Message msg=handler.obtainMessage();
        msg.arg1=3;
        msg.obj=" 测试结束 ";

        handler.sendMessage(msg);
    }
    public List execTransact(IBinder binder2,int intercode,Parcel data2,Parcel replay2){
        boolean resultcode;
        List list=new ArrayList();
        String str="";
        try {
            resultcode=binder2.transact(intercode,data2,replay2,0);
            list.add(resultcode);
            replay2.readException();
        } catch (Exception e) {
            Errorinfo2= MyApplication.getStackTraceInfo(e);   //异常写入
            list.add(Errorinfo2);
            LogUtil.e("打印异常","@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@开始打印异常@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
            LogUtil.e("异常信息",Errorinfo2);
            LogUtil.e("接口方法：","服务名"+ServiceNameMore+"接口方法-->"+paralist.get(3)+"  接口号-->"+paralist.get(2)+""+paraString);
            LogUtil.e("打印异常","@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@打印异常结束@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
            LogUtil.e("ERROR",paraString);
            for(int i=0;i<saveParalist.size();i++){
                str=str+"  "+saveParalist.get(i);
            }
            LogUtil.e("ERROR",str);

            e.printStackTrace();
        }
        finally {
            data2.recycle();
            replay2.recycle();
        }
        return list;
    }


    /**
     * 集合里面的数据  1，binder 2.服务名  3.接口号 4.接口方法  5.参数1 6.参数2 7.参数3
     * 对于无参数的接口，重复调用。
     */
    public  String[] getStyleNum(){       //1-A 2-b
        int len=paralist.size();
        String [] stylenum=new String[len-4];    //保存的数据长度
        for(int i=4;i<len;i++){
            String Para1= (String) FuzzmoreUtil.ParaStylePriority().get(paralist.get(i)); //从4开始，不用减4
            if(Para1==null){
                stylenum[i-4]="24-"+(char)(61+i);
            }
            else{
                stylenum[i-4]=Para1.split(" ")[1]+"-"+(char)(61+i);
            }
        }
        return stylenum;
    }


}
