package com.zzw.asfuzzer.Database;

import java.util.HashMap;
import java.util.List;

public class TableName {
    public static List table1;


    public TableName(List table){
        this.table1=table;
    }
    public TableName(){

    }


   public void setTable(List table){
        this.table1=table;
    }
   public List getTable(){
        return table1;
   }
    public static HashMap GetParaStyleRelation(){
        HashMap <String,String> ParaMap=new HashMap<>();  //<接口获取到的类型，需要构造的java类型>
        ParaMap.put("boolean","boolean 1");
        ParaMap.put("byte","byte 2");
        ParaMap.put("android.content.ComponentName","ComponentName 3");
        ParaMap.put("android.net.Uri","Uri 4");
        ParaMap.put("android.os.IBinder","IBinder 5");
        ParaMap.put("android.content.Intent","intent 6");
        ParaMap.put("[Z","boolean[] 7");
        ParaMap.put("int","int 8");
        ParaMap.put("java.lang.String","String 9");
        ParaMap.put("[B","byte[] 10");
        ParaMap.put("long","long 11");
        ParaMap.put("float","float 12");
        ParaMap.put("double","double 13");
        ParaMap.put("[I","int[] 14");
        ParaMap.put("[J","long[] 15");
        ParaMap.put("[Ljava.lang.String;","String[] 16");
        ParaMap.put("[Landroid.content.Intent;","Intent[] 17");
        ParaMap.put("java.util.List","List 18");
        ParaMap.put("[Landroid.content.ComponentName;","ComponentName[] 19");

        ParaMap.put("[F","float[] 20");
        ParaMap.put("[D","double[] 21");
        ParaMap.put("android.os.Bundle", "Bundle 22");

        ParaMap.put("java.lang.CharSequence", "CharSequence 23");   //多种形式
        ParaMap.put("Object","object 24");
        return ParaMap;
    }
}
